<?php
$con = mysqli_connect("localhost", "root", "", "hotelms");

// Print any errors that occur
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
} else {
  //  echo "Connected successfully!";
}
?>
