<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Casa Estela POS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="images/logo.png" alt="Casa Estela Logo">
            <h1>Casa Estela</h1>
        </div>
        <div class="nav">
            <button><i class="fas fa-bell"></i></button>
            <button><i class="fas fa-user"></i></button>
        </div>
    </header>

    <main>
        <aside>
            <nav>
                <ul>
                    <li><a href="#"><i class="fas fa-cash-register"></i> POS</a></li>
                    <li><a href="#"><i class="fas fa-clipboard-list"></i> Orders</a></li>
                    <li><a href="#"><i class="fas fa-chart-bar"></i> Sales</a></li>
                    <li><a href="#"><i class="fas fa-cog"></i> Settings</a></li>
                </ul>
            </nav>
        </aside>

        <section class="content">
            <h2>Point of Sale</h2>

            <div class="menu-categories">
                <h4>Menu Categories</h4>
                <ul>
                    <li>Breakfast</li>
                    <li>Small Plates</li>
                    <li>Soup & Salad</li>
                    <li>Pasta</li>
                    <li>Sandwiches</li>
                    <li>Coffee & Latte</li>
                    <li>Ice Blended</li>
                    <li>Tea</li>
                    <li>Other Drinks</li>
                </ul>
            </div>

            <div class="menu-items">
                <h4>Small Plates</h4>
                <div class="item">
                    <img src="imag/dish1.jpg" alt="Item 1">
                    <h5>Hand Cut Fries</h5>
                    <p>₱195.00</p>
                    <button>Add to Cart</button>
                </div>
                <div class="item">
                    </div>
            </div>

            <div class="cart">
                <h4>Cart</h4>
                <ul>
                    <li>Mozzarella Stick <span>Price: ₱285.00</span> <span>Qty: 2</span> <button>X</button></li>
                    <li>Sriracha Buffalo Wings <span>Price: ₱377.00</span> <span>Qty: 1</span> <button>X</button></li>
                </ul>
                <p>Total Items: 2</p>
                <p>Total Qty: 3</p>
                <p>Total: ₱947.00</p>
                <button>Place Order</button>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; Casa Estela. All Rights Reserved 2024</p>
    </footer>
</body>
</html>