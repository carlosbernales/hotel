<?php 
    include './db.php';
    $sql = "SELECT * FROM users";
    $query = $connection->query($sql);

    echo "$query->num_rows";

?>