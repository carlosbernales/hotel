<body>
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<img src="img/house.png" alt="Home Icon" style="width: 20px; height: 20px;">
				</a></li>
				<li class="active">Dashboard</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Dashboard</h1>
			</div>
		</div>

		<div class="panel panel-container">
			<!-- First row with 3 panels -->
			<div class="row">
				<div class="col-xs-6 col-md-4 col-lg-4 no-padding">
					<div class="panel panel-widget border-right">
						<div class="row no-padding">
							<img src="img/images.png" alt="Room Icon" class="panel-icon">
							<div class="large"><?php include 'counters/room-count.php'?></div>
							<div class="text-muted">Rooms</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-4 col-lg-4 no-padding">
					<div class="panel panel-widget border-right">
						<div class="row no-padding">
							<img src="img/reserved.png" alt="Reservation Icon" class="panel-icon">
							<div class="large"><?php include 'counters/reserve-count.php'?></div>
							<div class="text-muted">Reservations</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-4 col-lg-4 no-padding">
					<div class="panel panel-widget border-right">
						<div class="row no-padding">
							<img src="img/9150508.png" alt="Booked Rooms Icon" class="panel-icon">
							<div class="large"><?php include 'counters/bookedroom-count.php'?></div>
							<div class="text-muted">Booked Rooms</div>
						</div>
					</div>
				</div>
			</div><!--/.row-->

			<!-- Second row with 3 panels -->
			<div class="row">
				<div class="col-xs-6 col-md-4 col-lg-4 no-padding">
					<div class="panel panel-widget border-right">
						<div class="row no-padding">
							<img src="img/working.png" alt="Working Icon" class="panel-icon">
							<div class="large"><?php include 'counters/CustomInfo-count.php'?></div>
							<div class="text-muted">Customer Info</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-4 col-lg-4 no-padding">
					<div class="panel panel-widget border-right">
						<div class="row no-padding">
							<img src="img/available.png" alt="Available Rooms Icon" class="panel-icon">
							<div class="large"><?php include 'counters/avrooms-count.php'?></div>
							<div class="text-muted">Available Rooms</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-4 col-lg-4 no-padding">
					<div class="panel panel-widget border-right">
						<div class="row no-padding">
							<img src="img/61e7cd50c8a56a9b30e57c94_self-check-in.png" alt="Checked In Icon" class="panel-icon">
							<div class="large"><?php include 'counters/checkedin-count.php'?></div>
							<div class="text-muted">Checked In</div>
						</div>
					</div>
				</div>
			</div><!--/.row-->
		</div>
	</div><!--/.main-->
</body>

<style>
	/* Panel Styles */
	.panel-widget {
		background-color: transparent;
		border-radius: 10px;
		box-shadow: 0px 6px 20px rgba(0, 0, 0, 0.2);
		padding: 15px;
		text-align: center;
		transition: box-shadow 0.3s ease-in-out;
	}

	.panel-widget .panel-icon {
		width: 100px;
		height: 100px;
		border-radius: 50%;
		margin-bottom: 20px;
		transition: transform 0.3s ease-in-out;
	}

	.panel-widget:hover .panel-icon {
		transform: scale(1.1);
	}

	.panel-widget .large {
		font-size: 24px;
		font-weight: bold;
		color: #333;
	}

	.panel-widget .text-muted {
		color: #555;
		font-size: 14px;
	}

	.panel-widget:hover {
		box-shadow: 0px 10px 25px rgba(0, 0, 0, 0.3);
	}

	@media (max-width: 768px) {
		.panel-widget .panel-icon {
			width: 80px;
			height: 80px;
		}

		.panel-widget .large {
			font-size: 18px;
		}
	}
</style>
