<?php

session_start();


require 'db_con.php';

if (!isset($_SESSION['userid'])) {

    header("Location: login.php");
    exit();
}
function insertReservation($data, $pdo)
{
    try {
        $sql = "INSERT INTO reservation 
                (userid, room_name, price, checkin, checkout, message, meal, total_price, time_arrival, payment_method, payment_option, downpayment, remaining_balance, firstname, lastname, contact_number, address)
                VALUES (:userid, :room_name, :price, :checkin, :checkout, :message, :meal, :total_price, :time_arrival, :payment_method, :payment_option, :downpayment, :remaining_balance, :firstname, :lastname, :contact_number, :address)";
        $stmt = $pdo->prepare($sql);

        $stmt->bindParam(':userid', $data['userid']);
        $stmt->bindParam(':room_name', $data['room_name']);
        $stmt->bindParam(':price', $data['price']);
        $stmt->bindParam(':checkin', $data['checkin']);
        $stmt->bindParam(':checkout', $data['checkout']);
        $stmt->bindParam(':message', $data['message']);
        $stmt->bindParam(':meal', $data['meal']);
        $stmt->bindParam(':total_price', $data['total_price']);
        $stmt->bindParam(':time_arrival', $data['time_arrival']);
        $stmt->bindParam(':payment_method', $data['payment_method']);
        $stmt->bindParam(':payment_option', $data['payment_option']);
        $stmt->bindParam(':downpayment', $data['downpayment']);
        $stmt->bindParam(':remaining_balance', $data['remaining_balance']);
        $stmt->bindParam(':firstname', $data['firstname']);
        $stmt->bindParam(':lastname', $data['lastname']);
        $stmt->bindParam(':contact_number', $data['contact_number']);
        $stmt->bindParam(':address', $data['address']);

        $stmt->execute();

        // Set session variable to indicate successful reservation
        $_SESSION['reservation_made'] = true;

        // Success alert and redirect
        echo "<script>
                alert('Reservation successful!');
                window.location.href = 'rooms.php';
              </script>";

    } catch (PDOException $e) {
        error_log("Error inserting reservation: " . $e->getMessage());
        echo "Error: Could not save reservation.";
    }
}

$userid = $_SESSION['userid']; 
$room_name = "Standard Double Room";
$price = 3600; 
$checkin = isset($_POST['checkin']) ? $_POST['checkin'] : '';
$checkout = isset($_POST['checkout']) ? $_POST['checkout'] : '';
$message = isset($_POST['message']) ? $_POST['message'] : '';
$meal = isset($_POST['meal']) ? $_POST['meal'] : ''; 
$time_arrival = isset($_POST['time_arrival']) ? $_POST['time_arrival'] : '';
$payment_method = isset($_POST['paymentMethod']) ? $_POST['paymentMethod'] : 'gcash'; 
$payment_option = isset($_POST['paymentOption']) ? $_POST['paymentOption'] : 'downpayment'; 


$firstname = isset($_POST['firstname']) ? $_POST['firstname'] : '';
$lastname = isset($_POST['lastname']) ? $_POST['lastname'] : '';
$contact_number = isset($_POST['contact_number']) ? $_POST['contact_number'] : '';
$address = isset($_POST['address']) ? $_POST['address'] : '';

if (empty($checkin) || empty($checkout) || strtotime($checkin) >= strtotime($checkout)) {
    die("Invalid check-in or check-out date. Check-in must be before check-out.");
}


$days_stay = (strtotime($checkout) - strtotime($checkin)) / (60 * 60 * 24); 
$room_total_price = $price * $days_stay;
$meal_price = 0; 
$total_price = $room_total_price + $meal_price;

if ($payment_option == 'downpayment') {
    $downpayment = $total_price * 0.5;
    $remaining_balance = $total_price * 0.5; 
} elseif ($payment_option == 'fullyPaid') {

    $downpayment = 0;
    $remaining_balance = 0;
} else {
  
    $downpayment = 0;
    $remaining_balance = $total_price;
}

$reservationData = [
    'userid' => $userid,
    'room_name' => $room_name,
    'price' => $price,
    'checkin' => $checkin,
    'checkout' => $checkout,
    'message' => $message,
    'meal' => $meal,
    'total_price' => $total_price,
    'time_arrival' => $time_arrival,
    'payment_method' => $payment_method,
    'payment_option' => $payment_option,
    'downpayment' => $downpayment,
    'remaining_balance' => $remaining_balance,
    'firstname' => $firstname,
    'lastname' => $lastname,
    'contact_number' => $contact_number,
    'address' => $address,
];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    insertReservation($reservationData, $pdo);
}
?>
