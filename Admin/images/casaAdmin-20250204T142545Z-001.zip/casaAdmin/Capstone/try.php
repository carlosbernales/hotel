<?php
// Retrieve POST data safely
$room_name = isset($_POST['room_name']) ? $_POST['room_name'] : 'Not Specified';
$price = isset($_POST['price']) ? $_POST['price'] : 0;
$check_in = isset($_POST['check_in']) ? $_POST['check_in'] : 'Not Specified';
$check_out = isset($_POST['check_out']) ? $_POST['check_out'] : 'Not Specified';
$guests = isset($_POST['guests']) ? $_POST['guests'] : 'Not Specified';
$breakfast = isset($_POST['breakfast']) ? $_POST['breakfast'] : 'Not Specified';
$damage_deposit = isset($_POST['damage_deposit']) ? $_POST['damage_deposit'] : 0;

// Calculate total price
$total_price = $price + $damage_deposit;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Booking Details</title>
</head>
<body>
    <h2>Your Booking Details</h2>
    <p>Room: <?php echo htmlspecialchars($room_name); ?></p>
    <p>Guests: <?php echo htmlspecialchars($guests); ?></p>
    <p>Breakfast: <?php echo htmlspecialchars($breakfast); ?></p>
    <p>Check-In: <?php echo htmlspecialchars($check_in); ?></p>
    <p>Check-Out: <?php echo htmlspecialchars($check_out); ?></p>
    <p>Price: ₱ <?php echo number_format($price, 2); ?></p>
    <p>Damage Deposit (Refundable): ₱ <?php echo number_format($damage_deposit, 2); ?></p>
    <p>Total Price: ₱ <?php echo number_format($total_price, 2); ?></p>
</body>
</html>
