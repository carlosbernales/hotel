<?php
session_start();
require 'db_con.php';

// Check if the user has made a reservation
if (!isset($_SESSION['reservation_made']) || $_SESSION['reservation_made'] !== true) {
    // If no reservation, disable cafe ordering or show a message
    echo "<script>alert('Please make a reservation before placing an order.');</script>";
    echo "<script>window.location.href = 'rooms.php';</script>";  // Redirect to reservation page
    exit();  // Stop further execution of the page
}
// After placing the order, you can clear the session variable
//unset($_SESSION['reservation_made']);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Point of Sale</title>
    <!-- Bootstrap CSS -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Sidebar */
        .sidebar {
            height: 100vh;
            overflow-y: auto;
            position: fixed;
            top: 80px;
            left: 0;
            width: 25%;
            z-index: 1000;
        }
        .menu-items {
            margin-left: 25%;
            margin-top: 65px;
        }

        /* Current Order Section */
        .current-order {
            height: 100vh;
            overflow-y: auto;
            border-left: 1px solid #ddd;
            position: fixed;
            top: 80px;
            right: 0;
            width: 25%;
            background-color: #f8f9fa;
            z-index: 900;
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .current-order h3 {
            text-align: center;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .list-group-item{
            margin-bottom: 10px;
            border-radius: 12px;
            box-shadow: 0px 3px 3px 0px
        }

        .order-list {
            flex-grow: 1;
            overflow-y: auto;
            margin-bottom: 20px;
        }

        .order-list-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        .order-item-details {
            flex: 1;
        }

        .qty-controls {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .qty-button {
            background-color: #ffc107;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }

        .qty-display {
            padding: 0 10px;
            font-size: 1rem;
            min-width: 30px;
            text-align: center;
        }
        .qty-button.decrement {
            background-color: #dc3545;
            color: white;
        }


        .order-summary {
            background-color: #fff;
            padding: 15px;
            margin-bottom: 50px;
            border-radius: 8px;
            margin-left:  7px;
            font-size: 1.2rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .btn-success {
            width: 100%;
            font-size: 1rem;
            padding: 10px;
            margin-top: 15px;
        }

        /* Add-ons styles */
        .add-ons {
            margin-top: 10px;
        }

        .add-on-list {
            font-size: 0.9rem;
        }
        @media (max-width: 768px) {
            .sidebar,
            .current-order {
                position: relative;
                width: 100%;
                height: auto;
                border: none;
            }
            .menu-items {
                margin-left: 0;
            }
            .current-order {
                margin-top: 20px;
            }
        }
    </style>
</head>
<body>
 <!-- Navigation Bar -->
 <?php include('nav.php'); ?>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 sidebar bg-light">
                <h3 class="text-center py-3">Menu Categories</h3>
                <ul class="list-group" id="menu-categories">
                    <li class="list-group-item active" data-category="small-plates">SMALL PLATES</li>
                    <li class="list-group-item" data-category="soup-salad">SOUP & SALAD</li>
                    <li class="list-group-item" data-category="pasta">PASTA</li>
                    <li class="list-group-item" data-category="sandwiches">SANDWICHES</li>
                    <li class="list-group-item" data-category="coffe">COFFE & LATTE</li>
                    <li class="list-group-item" data-category="iceblend">ICE BLENDED</li>
                    <li class="list-group-item" data-category="tea">TEA</li>
                    <li class="list-group-item" data-category="otherdrinks">OTHER DRINKS</li>
                </ul>
            </div>

            <!-- Menu Items Section -->
            <div class="col-md-6 menu-items">
                <h3 class="text-center py-3">SMALL PLATES</h3>
                <div class="row" id="menu-items">
                    <!-- Menu Cards will be dynamically inserted here -->
                </div>
            </div>

            <!-- Current Order Section -->
            <div class="col-md-3 current-order">
                <h3>Current Order</h3>
                <div class="order-list" id="order-list"></div>
                <div class="order-summary">
                    <p><strong>Total Items:</strong> <span id="total-items">0</span></p>
                    <p><strong>Total Amount:</strong> ₱ <span id="total-amount">0.00</span></p>
                    <form id="order-form" action="ordersumarry.php" method="POST" style="display: none;">
                        <input type="hidden" name="order-details" id="order-details">
                    </form>
                    <button class="btn btn-success" onclick="submitOrder()">Place Order</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
 <!-- Inside the Order Summary Page -->

   // Serialize order data and submit the form
function submitOrder() {
    const orderForm = document.getElementById("order-form");
    const orderDetailsInput = document.getElementById("order-details");

    if (order.length === 0) {
        alert("Your order is empty. Please add items to your cart.");
        return;
    }

    // Serialize the order details into JSON
    orderDetailsInput.value = JSON.stringify(order);

    // Show a confirmation or loading state
    const placeOrderButton = document.querySelector(".btn-success");
    placeOrderButton.disabled = true;
    placeOrderButton.textContent = "Placing Order...";

    // Simulate form submission or redirect
    setTimeout(() => {
        orderForm.submit(); // Simulate form submission
    }, 1000); // Simulate server interaction delay
}

    // Sample Menu Data with Add-Ons
    const menuData = {
        "small-plates": [
            { 
                name: "Hand-cut Potato Fries", 
                price: 120,
                addons: [
                    { name: "Cheese", price: 30 },
                    { name: "Mayo", price: 50 }
                ]
            },
            { 
                name: "Mozzarella Stick", 
                price: 150,
                addons: [
                    { name: "Extra Sauce", price: 20 },
                    { name: "Extra Mozzarella", price: 40 }
                ]
            },
            { name: "Chicken Wings", price: 180, addons: [
                { name: "Buffalo Sauce", price: 25 },
                { name: "Extra Ranch", price: 30 }
            ]}
        ],
        "soup-salad": [
            { 
                name: "Hand-cut Potato Fries", 
                price: 120,
                addons: [
                    { name: "Cheese", price: 30 },
                    { name: "Bacon Bits", price: 50 }
                ]
            },
            { 
                name: "Mozzarella Stick", 
                price: 150,
                addons: [
                    { name: "Ranch Sauce", price: 20 },
                    { name: "Extra Mozzarella", price: 40 }
                ]
            }
        ]
    };

    // Handle Add to Cart
    let order = [];

    document.body.addEventListener("click", function (e) {
        if (e.target.classList.contains("add-to-cart")) {
            const itemName = e.target.getAttribute("data-item");
            const itemPrice = parseFloat(e.target.getAttribute("data-price"));
            const categoryName = e.target.getAttribute("data-category");
            const addons = [];

            // Collect selected add-ons
            const selectedAddons = document.querySelectorAll(`input.addon-checkbox[data-item="${itemName}"]:checked`);
            selectedAddons.forEach(addon => {
                addons.push({
                    name: addon.getAttribute("data-addon"),
                    price: parseFloat(addon.getAttribute("data-price"))
                });
            });

            addToOrder(itemName, itemPrice, categoryName, addons);
        }
    });

    function addToOrder(name, price, category, addons) {
        const existingItem = order.find((item) => item.name === name && item.category === category);
        if (existingItem) {
            existingItem.qty++;
            existingItem.addons.push(...addons);
        } else {
            order.push({ name, price, category, qty: 1, addons });
        }
        updateOrder();
    }

    function updateOrder() {
        const orderList = document.getElementById("order-list");
        const totalItems = document.getElementById("total-items");
        const totalAmount = document.getElementById("total-amount");

        orderList.innerHTML = order
            .map((item, index) => {
                const addonsList = item.addons.map(addon => ` 
                    <p>${addon.name}: +₱ ${addon.price}</p>
                `).join('');

                
                return `
                    <div class="order-list-item">
                        <div class="order-item-details">
                            <p><strong>Category:</strong> ${item.category}</p>
                            <p><strong>Item:</strong> ${item.name}</p>
                            ${addonsList}
                            <p>₱ ${item.price.toFixed(2)}</p>
                        </div>
                        <div class="qty-controls">
                            <button class="qty-button decrement" onclick="decrementQty(${index})">-</button>
                            <span class="qty-display">${item.qty}</span>
                            <button class="qty-button" onclick="incrementQty(${index})">+</button>
                        </div>
                    </div>
                `;
            })
            .join("");

        totalItems.textContent = order.reduce((total, item) => total + item.qty, 0);
        totalAmount.textContent = order
            .reduce((total, item) => total + item.price * item.qty + item.addons.reduce((sum, addon) => sum + addon.price, 0), 0)
            .toFixed(2);
    }

    function incrementQty(index) {
        order[index].qty++;
        updateOrder();
    }

    function decrementQty(index) {
        if (order[index].qty > 1) {
            order[index].qty--;
        } else {
            order.splice(index, 1);
        }
        updateOrder();
    }

    function updateMenuItems(category) {
        const menuItemsContainer = document.getElementById("menu-items");
        menuItemsContainer.innerHTML = "";

        if (menuData[category]) {
            menuData[category].forEach((item) => {
                let addonOptions = '';
                if (item.addons.length > 0) {
                    addonOptions = `
                        <div class="add-ons">
                            <h6>Add-ons:</h6>
                            <div class="add-on-list">
                                ${item.addons.map(addon => `
                                    <label>
                                        <input type="checkbox" class="addon-checkbox" data-item="${item.name}" data-addon="${addon.name}" data-price="${addon.price}" />
                                        ${addon.name} (+₱ ${addon.price})
                                    </label><br>
                                `).join('')}
                            </div>
                        </div>
                    `;
                }

                const card = `
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="images/fries.jpg" class="card-img-top" alt="${item.name}">
                            <div class="card-body text-center">
                                <h5 class="card-title">${item.name}</h5>
                                <p class="card-text">₱ ${item.price.toFixed(2)}</p>
                                <button class="btn btn-warning add-to-cart" data-item="${item.name}" data-price="${item.price}" data-category="${category}">Add to Cart</button>
                                ${addonOptions}
                            </div>
                        </div>
                    </div>
                `;
                menuItemsContainer.innerHTML += card;
            });
        }
    }

    // Set default category to "small-plates" and update menu items
    document.addEventListener("DOMContentLoaded", function() {
        const defaultCategory = "small-plates";
        updateMenuItems(defaultCategory);

        // Category selection event
        document.getElementById("menu-categories").addEventListener("click", function(e) {
            if (e.target && e.target.matches("li")) {
                document.querySelectorAll('.list-group-item').forEach((item) => {
                    item.classList.remove("active");
                });
                e.target.classList.add("active");
                updateMenuItems(e.target.getAttribute("data-category"));
            }
        });
    });
</script>
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
