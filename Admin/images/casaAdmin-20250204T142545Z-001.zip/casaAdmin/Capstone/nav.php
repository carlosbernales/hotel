<nav class="navbar navbar-expand-lg navbar-light bg-warning">
    <div class="container">
        <h3 class="navbar-brand">E-Akomoda</h3>

        <div class="d-lg-none d-flex align-items-center">
            <a href="#" class="nav-link notification-icon">
                <i class="fas fa-bell"></i>
            </a>
            <a href="#" class="nav-link notification-icon">
                <i class="fas fa-envelope"></i>
            </a>         
        </div>

        <li class="nav-item dropdown d-lg-none">
            <a class="nav-link dropdown-toggle" href="#" id="logoutDropdownMobile" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                My Profile <i class="fas fa-sign-out-alt"></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="logoutDropdownMobile">
                <li class="d-flex align-items-center">
                <i class="bi bi-person-fill"></i><a class="dropdown-item" href="profile.php">My Profile</a>
                </li>
                <li class="d-flex align-items-center">
                    <i class="fas fa-bookmark me-2"></i><a class="dropdown-item" href="reservations.php">Bookings Reservation</a>
                </li>
                <li class="d-flex align-items-center">
                    <i class="fas fa-box-open me-2"></i><a class="dropdown-item" href="myorders.php">My Orders</a>
                </li>
                <li class="d-flex align-items-center">
                    <i class="fas fa-comments me-2"></i><a class="dropdown-item" href="feedback.php">Feedback</a>
                </li>
                <li class="d-flex align-items-center">
                    <i class="fas fa-sign-out-alt me-2"></i><a class="dropdown-item" href="logout.php">Log Out</a>
                </li>
            </ul>
        </li>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="home.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="rooms.php">Rooms</a></li>
                <li class="nav-item"><a class="nav-link" href="cafes.php">Café</a></li>
                <li class="nav-item"><a class="nav-link" href="events.html">Events</a></li>
                <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>

                <li class="nav-item d-none d-lg-inline-block">
                    <a href="#" class="nav-link notification-icon">
                        <i class="fas fa-bell"></i>
                    </a>
                </li>
                <li class="nav-item d-none d-lg-inline-block">
                    <a href="#" class="nav-link notification-icon">
                        <i class="fas fa-envelope"></i>
                    </a>
                </li>

                <!-- Log Out Dropdown for Desktop -->
                <li class="nav-item dropdown d-none d-lg-inline-block">
                    <a class="nav-link dropdown-toggle" href="#" id="logoutDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        My Profile <i class="fas fa-sign-out-alt"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="logoutDropdown">
                        <li class="d-flex align-items-center">
                            <i class="bi bi-person-fill me-2"></i><a class="dropdown-item" href="profile.php">My Profile</a>
                        </li>
                        <li class="d-flex align-items-center">
                            <i class="fas fa-bookmark me-2"></i><a class="dropdown-item" href="reservations.php">Bookings Reservation</a>
                        </li>
                        <li class="d-flex align-items-center">
                            <i class="fas fa-box-open me-2"></i><a class="dropdown-item" href="myorders.php">My Orders</a>
                        </li>
                        <li class="d-flex align-items-center">
                            <i class="fas fa-sign-out-alt me-2"></i><a class="dropdown-item" href="logout.php">Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>


<style>
        body {
        font-family: "Poppins", serif;
        font-weight: 200;
        font-style: normal;
         }
        .navbar {
            font-family: 'Playfair Display', serif;
            border-bottom: 2px solid white;
            position: fixed;
            z-index: 1000;
            top: -5px;
            width: 100%;          
        }
        .navbar-brand {
            margin-right: 20px;
            font-size: 24px;
            font-family: 'Playfair Display', serif;   
        }
        .nav-link {
            color: black;
            font-weight: 900;
            padding: 10px;
        }
        .nav-link:hover {
            background-color: #856f11;
            color: white;
            border-radius: 5px;
        }
        .notification-icon {
            font-size:18px;
            position: relative;
            color: black;
        }
        .notification-icon .notification-badge {
            position: absolute;
            top: -5px;
            right: -10px;
            background: red;
            color: white;
            font-size: 10px;
            border-radius: 50%;
            padding: 2px 6px;
        }
        .nav-link .dropdown-toggle{
            margin-right: 10px;

        }


        .footer {
            width: 100%;
            height: 28px;
            background-color:#d4af37;
            text-align: center;
            margin-top: 20px;
            border-radius: 8px;
        }
/* Optional: Adjust icon alignment for smaller screens */
@media (max-width: 576px) {
    .navbar {
        padding: 10px 20px; /* Adjust padding for mobile */
    }
    body{

        padding-top: 50px;
    }
    .navbar-brand {
        margin-right: auto;
    }

        .navbar {
            position: fixed; 
            top: 0;
            left: 0;
            width: 100%;   
            z-index: 1000;
            margin-top: -15px; 
        }
        .notification-icon
        {
            font-size: 20px;
            margin: 0px 0px 0px 10px ;
        }
        .nav-item{
            color:black;
            font-size: 15px;
            margin-right: 10px;
            margin-bottom: 25px;
            
        }
        .footer {
            width: 100%;
            height: 28px;
            background-color:#d4af37;
            text-align: center;
            margin-top: 20px;
            border-radius: 8px;
        }
    }
    @media (max-width: 782px) {
    .navbar {
        padding: 10px 20px; /* Adjust padding for mobile */
    }
    body{

        padding-top: 50px;
    }
    .navbar-brand {
        margin-right: auto;
    }

        .navbar {
            position: fixed; 
            top: 0;
            left: 0;
            width: 100%;   
            z-index: 1000; 
        }
        .notification-icon
        {
            font-size: 15px;
            margin: 0px 0px 0px 10px ;
        }
        .nav-item{
            color:black;
            font-size: 15px;
            margin-right: 10px;
            margin-bottom: 25px;
            
        }
        .footer {
            width: 100%;
            height: 28px;
            background-color:#d4af37;
            text-align: center;
            margin-top: 20px;
            border-radius: 8px;
        }
    
    }  
    @media (max-width: 1000px) {
    .navbar {
        padding: 0px 20px; /* Adjust padding for mobile */
    }

    .navbar-brand {
        margin-right: auto;
    }

        .navbar {
            position: fixed; 
            top: 0;
            left: 0;
            width: 100%;   
            z-index: 1000; 
        }
        .notification-icon
        {
            font-size: 15px;
            margin: 0px 0px 0px 10px ;
        }
        .nav-item{
            color:black;
            font-size: 15px;
            margin-right: 10px;
            margin-bottom: 25px;
            
        }   
        .footer {
            width: 100%;
            height: 28px;
            background-color:#d4af37;
            text-align: center;
            margin-top: 20px;
            border-radius: 8px;
        }
    }      
</style>
