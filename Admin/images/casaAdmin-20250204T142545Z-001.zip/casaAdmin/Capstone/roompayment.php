
<?php require 'db_con.php'; ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            align-items: center;
            padding: 20px
            width: 600px;
            
        }

            .container {
            max-width: 600px;
            width: 100%;     
            margin: 20px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            border: 1px solid #d4af37;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .containers {
            max-width: 600px; 
            width: 90%;    
            margin: 20px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            border: 1px solid #d4af37;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }


        .header {
            text-align: center;
            font-family: 'Playfair Display', serif;
        }

        .header h1 {
            font-size: 28px;
            font-weight: 900;
            color: #d4af37;
        }

        .header h2 {
            font-size: 18px;
            font-weight: 600;
            text-transform: uppercase;
            color: #d4af37;
        }

        .section-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
            color: #d4af37;
        }

        .form-control {
            border: 1px solid #e0e0dd;
            border-radius: 5px;
            padding: 10px;
        }
        .form-section{
            width: 500px;
        }

        .form-control:focus {
            border-color: #d4af37;
            box-shadow: none;
        }

        .details-section {
            border-top: 2px solid #d4af37;
            margin-top: 20px;
            padding-top: 20px;
        }

        .room-details {
            font-size: 14px;
            margin-bottom: 10px;
        }

        .price-details {
            font-size: 14px;
            font-weight: bold;
        }

        .price-details span {
            float: right;
        }

        .btn-warning {
            background-color: #d4af37;
            color: white;
            font-weight: bold;
            border: none;
            width: 100%;
            padding: 12px;
        }

        .btn-warning:hover {
            background-color: #c19a32;
        }

        .icon {
            color: #d4af37;
            margin-right: 5px;
        }
        
        .card {
            max-width: 500px;
            margin: auto;
            border-radius: 15px;
            border: none;
        }

        .title {
            font-family: "Playfair Display", serif;
            font-size: 36px;
            font-weight: 900;
            color: #d4af37;
            text-align: center;
            margin: 0;
        }

        .subtitle {
            font-family: "Playfair Display", serif;
            font-size: 16px;
            font-weight: 600;
            color: #d4af37;
            text-align: center;
            margin-top: -10px;
            text-decoration: underline;
        }
        

        .btn-warning {
            border-radius: 20px;
        }
        .container{
            width: 50%;
        }

        #mayaButton, #gcashButton {
            width: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn img {
            height: 24px;
            width: auto;
        }
        #bookingModal{
            width: 900px;
            padding-left: 500px;
        }
        .modal-body {
            width: 400px;
        }
        @media (max-width: 576px) {
            .form-control{
                
            }
            input{
                width: 200px;
            }
        }
        
    </style>
</head>
<body>
    <div class="containers">
        <!-- Header -->
        <div class="header">
            <h1>CASA ESTELA</h1>
            <h2>BOUTIQUE HOTEL & CAFE</h2>
        </div>
        <?php

$room_name = "Standard Double Room";
$price = 3600; 
$message = isset($_POST['message']) ? $_POST['message'] : '';


$time_arrival = '';
$payment_method = '';
$payment_option = '';
$first_name = '';
$last_name = '';
$phone = '';


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $first_name = isset($_POST['firstname']) ? $_POST['firstname'] : '';
    $last_name = isset($_POST['lastname']) ? $_POST['lastname'] : '';
    $phone = isset($_POST['phone']) ? $_POST['phone'] : '';  

    $time_arrival = isset($_POST['time_arrival']) ? $_POST['time_arrival'] : '';
    $payment_method = isset($_POST['paymentMethod']) ? $_POST['paymentMethod'] : '';
    $payment_option = isset($_POST['paymentOption']) ? $_POST['paymentOption'] : '';

    $checkin = isset($_POST['checkin']) ? $_POST['checkin'] : '';
    $checkout = isset($_POST['checkout']) ? $_POST['checkout'] : '';
    $days_stay = (strtotime($checkout) - strtotime($checkin)) / (60 * 60 * 24);
    $room_total_price = $price * $days_stay;
    $total_price = $room_total_price; 
}
?>


<div class="form-section">
    <p class="section-title">Enter your details</p>
    <form id="reservationForm" action="reservationfinal.php" method="post">
       
        <div class="row mb-3">
            <div class="col-12 col-md-6">
                <label for="firstName" class="form-label">First Name*</label>
                <input type="text" id="firstName" class="form-control" placeholder="Enter your first name" required name="firstname">
            </div>
            <div class="col-12 col-md-6">
                <label for="lastName" class="form-label">Last Name*</label>
                <input type="text" id="lastName" class="form-control" placeholder="Enter your last name" required name="lastname">
            </div>
        </div>


        <div class="row mb-3">
            <div class="col-12 col-md-6">
                <label for="phone" class="form-label">Phone Number (optional)</label>
                <input type="text" id="phone" class="form-control" placeholder="Enter your phone number" name="contact_number">
            </div>
            <div class="col-12 col-md-6">
                <label for="address" class="form-label">Address*</label>
                <input type="text" id="address" class="form-control" placeholder="Enter your address" required name="address">
            </div>
        </div>

        <hr>


        <div class="row mb-3">
            <div class="col-12 col-md-6">
                <label for="checkin-date" class="col-md-4">Check-In</label>
                <input type="date" name="checkin" class="form-control" id="checkin" required>
            </div>
            <div class="col-12 col-md-6">
                <label for="checkout-date" class="col-md-4">Check-Out</label>
                <input type="date" name="checkout" class="form-control" id="checkout" required min="" oninput="setCheckoutMin()">
            </div>                       
        </div>


        <div class="row mb-3">
            <div class="col-12 col-md-6">
                <label for="arrival" class="col-md-4">Time</label>
                <input type="time" name="time_arrival" class="form-control" id="time_arrival" required>
            </div>
            <div class="col-12 col-md-6">
                <label for="paymentMethod" class="form-label">Payment Method</label>
                <select id="paymentMethod" name="paymentMethod" class="form-control" required>
                    <option value="None">Select Payment</option>
                    <option value="Gcash" required>GCash</option>
                    <option value="Maya" required>Maya</option>
                </select>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-12">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="paymentOption" value="downpayment" id="downpayment" required>
                    <label class="form-check-label" for="downpayment">Downpayment</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="paymentOption" value="fullyPaid" id="fullyPaid">
                    <label class="form-check-label" for="fullyPaid">Fully Paid</label>
                </div>
            </div>
        </div>

        <!-- Submit Button -->
        <div class="row mt-4">
            <div class="col-12">
                <button type="button" class="btn btn-warning w-100" id="submitBtn" data-bs-toggle="modal" data-bs-target="#bookingModal">Submit Reservation</button>
            </div>
        </div>
    </form>
</div>

<!-- Booking Modal -->
<div class="modal fade" id="bookingModal" tabindex="-1" aria-labelledby="bookingModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="bookingModalLabel">Confirm Your Booking</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="section-title">Your Booking Details:</p>
                <p class="room-details">
                    <strong>Room Name:</strong> <span id="modalRoomName">Standard Double Room</span><br>
                    <strong>First Name:</strong> <span id="modalFirstName"></span><br>
                    <strong>Last Name:</strong> <span id="modalLastName"></span><br>
                    <strong>Phone Number:</strong> <span id="modalPhone"></span><br>
                    <strong>Address:</strong> <span id="modalAddress"></span><br>
                    <strong>Check-In:</strong> <span id="modalCheckin"></span><br>
                    <strong>Check-Out:</strong> <span id="modalCheckout"></span><br>
                    <strong>Arrival Time:</strong> <span id="modalArrival"></span><br>
                    <strong>Payment Method:</strong> <span id="modalPaymentMethod"></span><br>
                    <strong>Payment Option:</strong> <span id="modalPaymentOption"></span><br>
                </p>
                <hr>
                <p class="price-details">
                    <strong>Price:</strong> <span id="modalPrice"></span> per night<br>
                    <strong>Total Price:</strong> <span id="modalTotalPrice"></span><br>
                    <strong>Payment Option:</strong> <span id="modalDownpayment"></span>
                </p>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-lg btn-success" id="confirmReservation" form="reservationForm">Confirm Reservation</button>
                
            </div>
        </div>
    </div>
</div>

<script>

        const modalElement = document.getElementById('bookingModal');
        modalElement.addEventListener('hidden.bs.modal', function () {
            // Remove any remaining backdrop
            const backdrops = document.querySelectorAll('.modal-backdrop');
            backdrops.forEach(backdrop => backdrop.remove());
            document.body.classList.remove('modal-open'); 
            document.body.style.paddingRight = ''; 
        });


        document.getElementById('submitBtn').addEventListener('click', function (e) {
    e.preventDefault();

    var firstName = document.getElementById('firstName').value;
    var lastName = document.getElementById('lastName').value;
    var phone = document.getElementById('phone').value;
    var address = document.getElementById('address').value;
    var checkin = document.getElementById('checkin').value;
    var checkout = document.getElementById('checkout').value;
    var timeArrival = document.getElementById('time_arrival').value;
    var paymentMethod = document.getElementById('paymentMethod').value;
    var paymentOption = document.querySelector('input[name="paymentOption"]:checked')?.value;

    // Validate check-in and check-out dates
    if (new Date(checkin) >= new Date(checkout)) {
        alert("Invalid check-in or check-out date. Check-in must be before check-out.");
        return;
    }

    // Populate modal details
    document.getElementById('modalFirstName').textContent = firstName;
    document.getElementById('modalLastName').textContent = lastName;
    document.getElementById('modalPhone').textContent = phone;
    document.getElementById('modalAddress').textContent = address;
    document.getElementById('modalCheckin').textContent = checkin;
    document.getElementById('modalCheckout').textContent = checkout;
    document.getElementById('modalArrival').textContent = timeArrival;
    document.getElementById('modalPaymentMethod').textContent = paymentMethod;
    document.getElementById('modalPaymentOption').textContent = paymentOption;

    // Calculate prices
    var pricePerNight = 3600; // Price per night
    var checkinDate = new Date(checkin);
    var checkoutDate = new Date(checkout);
    var daysStay = (checkoutDate - checkinDate) / (1000 * 60 * 60 * 24);
    var totalPrice = pricePerNight * daysStay;
    var downpayment = totalPrice / 2;

    // Display prices
    document.getElementById('modalPrice').textContent = pricePerNight;
    document.getElementById('modalTotalPrice').textContent = totalPrice;

    // Show payment option details
    if (paymentOption === 'downpayment') {
        document.getElementById('modalDownpayment').textContent = `Downpayment: PHP ${downpayment.toFixed(2)}`;
    } else if (paymentOption === 'fullyPaid') {
        document.getElementById('modalDownpayment').textContent = `Fully Paid: PHP ${totalPrice.toFixed(2)}`;
    } else {
        document.getElementById('modalDownpayment').textContent = 'N/A';
    }

    // Show the modal
    var modal = new bootstrap.Modal(document.getElementById('bookingModal'));
    modal.show();
});

</script>



<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
  

            const mayaButton = document.getElementById("mayaButton");
            const gcashButton = document.getElementById("gcashButton");
            const mayaForm = document.getElementById("mayaForm");
            const gcashForm = document.getElementById("gcashForm");
    
            // Show Maya Payment Form
            mayaButton.addEventListener("click", () => {
                mayaForm.classList.remove("d-none");
                gcashForm.classList.add("d-none");
                mayaButton.classList.add("btn-warning");
                mayaButton.classList.remove("btn-outline-secondary");
                gcashButton.classList.add("btn-outline-secondary");
                gcashButton.classList.remove("btn-warning");
            });
    
            // Show G-Cash Payment Form
            gcashButton.addEventListener("click", () => {
                gcashForm.classList.remove("d-none");
                mayaForm.classList.add("d-none");
                gcashButton.classList.add("btn-warning");
                gcashButton.classList.remove("btn-outline-secondary");
                mayaButton.classList.add("btn-outline-secondary");
                mayaButton.classList.remove("btn-warning");
            });
    
            // Maya Form Submit
            mayaForm.addEventListener("submit", (e) => {
                e.preventDefault();
                const receipt = document.getElementById("mayaReceipt").files[0];
                if (receipt) {
                    alert(`Payment with Maya Confirmed! Receipt: ${receipt.name}`);
                } else {
                    alert("Payment with Maya Confirmed!");
                }
            });
    
            // G-Cash Form Submit
            gcashForm.addEventListener("submit", (e) => {
                e.preventDefault();
                const receipt = document.getElementById("gcashReceipt").files[0];
                if (receipt) {
                    alert(`Payment with G-Cash Confirmed! Receipt: ${receipt.name}`);
                } else {
                    alert("Payment with G-Cash Confirmed!");
                }
            });
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>


</body>
</html>
