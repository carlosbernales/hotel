<?php
require 'db_con.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Check CSRF token
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("CSRF token validation failed.");
    }

    $userid = intval($_SESSION['userid']);
    $name = htmlspecialchars($_POST['firstname']);
    $username = htmlspecialchars($_POST['username']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['contactnum']);
    $password = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : null;

    // Handle profile photo upload
    $profile_photo = $_FILES['profile_photo']['name'] ?? null;
    if ($profile_photo) {
        $target_dir = "images/"; // Change to the 'images' directory

        // Check if the 'images' directory exists and is writable
        if (!is_dir($target_dir)) {
            die("Images directory does not exist.");
        }

        if (!is_writable($target_dir)) {
            die("Images directory is not writable.");
        }

        // Define target file path
        $target_file = $target_dir . basename($profile_photo);

        // Attempt to move the uploaded file
        if (!move_uploaded_file($_FILES['profile_photo']['tmp_name'], $target_file)) {
            die("Error uploading profile photo.");
        }
    }

    try {
        // Update user details
        $sql = "UPDATE users SET firstname = :firstname, username = :username, email = :email, contactnum = :contactnum, 
                password = IFNULL(:password, password), profile_photo = IFNULL(:profile_photo, profile_photo) 
                WHERE userid = :userid";
        $stmt = $pdo->prepare($sql);

        $stmt->bindValue(':firstname', $name);
        $stmt->bindValue(':username', $username);
        $stmt->bindValue(':email', $email);
        $stmt->bindValue(':contactnum', $phone);
        $stmt->bindValue(':password', $password);
        $stmt->bindValue(':profile_photo', $profile_photo);
        $stmt->bindValue(':userid', $userid, PDO::PARAM_INT);

        if ($stmt->execute()) {
            header("Location: profile.php?success=1");
            exit();
        } else {
            echo "Error updating profile.";
        }
    } catch (PDOException $e) {
        echo "Error updating profile: " . $e->getMessage();
    }
} else {
    die("Invalid request.");
}
?>
