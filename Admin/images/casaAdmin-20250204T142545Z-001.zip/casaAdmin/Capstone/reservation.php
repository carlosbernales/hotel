
<?php
require 'db_con.php';
if (isset($_POST['insertBooking'])) {
    // Retrieve form data
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $phone = $_POST['phone'] ?? null;
    $address = $_POST['address'];
    $city = $_POST['city'];
    $country = $_POST['country'];
    $checkIn = $_POST['checkIn'];
    $checkOut = $_POST['checkOut'];
    $roomType = $_POST['roomType'];
    $totalPrice = $_POST['totalPrice'];
    $arrivalTime = $_POST['arrivalTime'] ?? null;

    try {
        // Check for empty fields
        if (
            empty($firstName) || empty($lastName) || empty($email) ||
            empty($address) || empty($city) || empty($country) || empty($checkIn) ||
            empty($checkOut) || empty($roomType) || empty($totalPrice)
        ) {
            echo '<script>alert("All required fields must be filled out!");</script>';
            exit;
        }

        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo '<script>alert("Invalid email address!");</script>';
            exit;
        }

        // Validate total price (must be a positive number)
        if (!is_numeric($totalPrice) || $totalPrice <= 0) {
            echo '<script>alert("Invalid total price!");</script>';
            exit;
        }

        // Check for conflicting reservations (optional)
        $checkSql = 'SELECT COUNT(*) FROM reservations WHERE room_type = :roomType AND (
                        (check_in BETWEEN :checkIn AND :checkOut) OR
                        (check_out BETWEEN :checkIn AND :checkOut)
                     )';
        $stmt = $pdo->prepare($checkSql);
        $stmt->execute([
            'roomType' => $roomType,
            'checkIn' => $checkIn,
            'checkOut' => $checkOut
        ]);

        if ($stmt->fetchColumn() > 0) {
            echo '<script>alert("The selected room type is already booked for these dates!");</script>';
            exit;
        }

        // Insert data into the database
        $sql = 'INSERT INTO reservations (first_name, last_name, email, phone, address, city, country, check_in, check_out, room_type, total_price, arrival_time) 
                VALUES (:firstName, :lastName, :email, :phone, :address, :city, :country, :checkIn, :checkOut, :roomType, :totalPrice, :arrivalTime)';
        $stmt = $pdo->prepare($sql);
        $data = [
            'firstName' => $firstName,
            'lastName' => $lastName,
            'email' => $email,
            'phone' => $phone,
            'address' => $address,
            'city' => $city,
            'country' => $country,
            'checkIn' => $checkIn,
            'checkOut' => $checkOut,
            'roomType' => $roomType,
            'totalPrice' => $totalPrice,
            'arrivalTime' => $arrivalTime
        ];
        $stmt->execute($data);

        // Success alert and optional redirect
        echo "<script>alert('Booking successfully created!'); window.location.href = 'booking_confirmation.php';</script>";
        exit;
    } catch (PDOException $e) {
        // Handle database errors
        echo '<script>alert("Error: ' . $e->getMessage() . '");</script>';
    }
}
?>
