<?php

session_start();
require 'db_con.php';

// Check if the user is logged in
if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit();
}

// Function to fetch reservations for the logged-in user
function fetchUserReservation($userid, $pdo)
{
    try {
        $sql = "SELECT reservation_id, room_name, price, checkin, checkout, total_price, payment_method, payment_option, remaining_balance 
                FROM reservation 
                WHERE userid = :userid";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':userid', $userid, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error fetching reservations: " . $e->getMessage());
        return [];
    }
}

// Fetch the current user's reservations
$userid = $_SESSION['userid'];
$reservations = fetchUserReservation($userid, $pdo);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Reservations</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h1 class="mb-4">Your Reservations</h1>

    <!-- Display User-Specific Reservations -->
    <?php if (!empty($reservations)): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Room Name</th>
                    <th>Price (PHP)</th>
                    <th>Check-in</th>
                    <th>Check-out</th>
                    <th>Total Price (PHP)</th>
                    <th>Payment Method</th>
                    <th>Payment Option</th>
                    <th>Remaining Balance</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($reservations as $reservation): ?>
                    <tr>
                        <td><?= htmlspecialchars($reservation['room_name']) ?></td>
                        <td><?= htmlspecialchars(number_format($reservation['price'], 2)) ?></td>
                        <td><?= htmlspecialchars($reservation['checkin']) ?></td>
                        <td><?= htmlspecialchars($reservation['checkout']) ?></td>
                        <td><?= htmlspecialchars(number_format($reservation['total_price'], 2)) ?></td>
                        <td><?= htmlspecialchars($reservation['payment_method']) ?></td>
                        <td><?= htmlspecialchars($reservation['payment_option'] === 'fullyPaid' ? 'Fully Paid' : 'Downpayment') ?></td>
                        <td>
                            <?= $reservation['payment_option'] === 'downpayment' ? 
                                htmlspecialchars(number_format($reservation['remaining_balance'], 2)) : 
                                'N/A' ?>
                        </td>
                        <td>
                            <!-- Buttons for cancel and change -->
                            <form action="reservation_actions.php" method="POST" class="d-inline">
                                <input type="hidden" name="reservation_id" value="<?= $reservation['reservation_id'] ?>">
                                <button type="submit" name="cancel" class="btn btn-danger btn-sm">Cancel</button>
                            </form>
                            <form action="change_room.php" method="GET" class="d-inline">
                                <input type="hidden" name="reservation_id" value="<?= $reservation['reservation_id'] ?>">
                                <button type="submit" class="btn btn-warning btn-sm">Change Room</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="alert alert-warning">No reservations found for your account.</p>
    <?php endif; ?>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
