<?php require 'db_con.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Casa Estela - Rooms</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body{
            font-family: "Poppins", serif;
            font-weight: 700;
            font-style: normal;
        }
        .form-inline{
            margin-top: 50px;
        }
   
        .form-inline .form-control {
            width: 200px;
        }
        form{
            margin-top: 20px;
            right: -20px
        }
        .row{
            padding-top: 100px;
        }
        .modal, .row{
            top: -100px;
        }
        .card-title {
            font-weight: bold;
        }

        .card-text {
            font-size: 1.2em;
            color: #333;
        }
       

        .text-danger {
            font-weight: bold;
            color: red;
        }
        .modal-body .row {
    gap: 20px; /* Adds space between carousel and form */
            
            }
        .modal{
            top: 50px;
        }
        .modal-body {
            width: 100%;
            left: 0px; /* Adjust left as needed */
            padding-top: 10px; /* Adds padding at the top of the modal content */
            display: flex;
            align-items: center;
        }

        .modal-body, .form-content {
            margin-bottom: 5px; /* Shifts the image inside the carousel 5px to the left */
            top: -100px;
        }
        .contents{
            left: 320px;
            top: -280px;
            margin-left: 20px; 
        }
        .form-content{
            width:280px;
            right: 320px;
            margin-top: -470px;
            padding-left: 30px;
        }

        #message{
            height: 40px;
            width: 100%;
        }
        .btn{
            margin: 10px;
            right: 5px
            
        }
            @media (max-width: 567px) {
        
        .form-wrapper {
            flex-direction: column;
        }
        

       
        .form-inline{
            padding:    0px 10px 0px 10px;
            justify-content: space-between ;
        }
        .form-control{
            margin: 10px;
            padding: 5px;
        }
        input , .form-control{
            padding: 8px;
        }
        input, .form-inline{
            margin: 5px;
        }
        .modal-body{
            width: 100%;
            left: 0px
        }
        .contents{
            left: -20px;
            top: -20px;
            margin-left: 20px; 
        }
        .form-content{
            width:100%;
            right: 320px;
            margin-top: 0px;
            padding-left: 10px;
            padding-right: 10px;
            padding-bottom: -5 px;
        }
        .btn{
            margin: 10px;
            right: 5px
            
        }
        #btnsearch {
            margin: 10px;
        }
  
        #reservation-section {
            order: 1;
        }

        #message-section {
            order: 2;
            margin-top: 20px; 
        }
    }    
    @media (max-width: 700px) {
        
        .form-wrapper {
            flex-direction: column;
        }
        

      
        .form-inline{
            padding:    0px 10px 0px 10px;
            justify-content: space-between ;
        }
        .form-control{
            margin: 10px;
            padding: 5px;
        }
        input , .form-control{
            padding: 8px;
        }
        input, .form-inline{
            margin: 5px;
        }
        .modal-body{
            width: 100%;
            left: 0px
        }
        .contents{
            left: -20px;
            top: -20px;
            margin-left: 20px; 
        }
        .form-content{
            width:100%;
            right: 320px;
            margin-top: 0px;
            padding-left: 10px;
            padding-right: 10px;
            padding-bottom: 0px;
        }
        .btn{
            margin: 10px;
            right: 5px
            
        }
        #btnsearch {
            margin: 10px;
        }
  
        #reservation-section {
            order: 1;
        }

        #message-section {
            order: 2;
            margin-top: 20px; 
        }
    }   
</style>

    </style>
</head>
<body>
 <!-- Navigation Bar -->
 <?php include('nav.php'); ?>
    <!-- Room Cards -->
    <div class="container">
        <div class="row">
            <!-- Standard Double Room -->
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="images/double.jpg" class="card-img-top" alt="Standard Double Room">
                    <div class="card-body">
                        <h5 class="card-title">Standard Double Room</h5>
                        <p class="card-text">₱3,200 per night</p>
                        <p>Only 3 rooms left</p>                  
                        <button class="btn btn-warning mt-2" data-toggle="modal" data-target="#roomModal">Book Now</button>
                    </div>
                </div>
            </div>

            <!-- Family Room -->
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="images/4.jpg" class="card-img-top" alt="Family Room">
                    <div class="card-body">
                        <h5 class="card-title">Family Room</h5>
                        <p class="card-text">₱4,200 per night</p>
                        <p>Only 1 room left</p>
                        <button class="btn btn-warning mt-2" data-toggle="modal" data-target="#roomModal2">Book Now</button>
                    </div>
                </div>
            </div>

            <!-- Deluxe Family Room -->
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="images/3.jpg" class="card-img-top" alt="Deluxe Family Room">
                    <div class="card-body">
                        <h5 class="card-title">Deluxe Family Room</h5>
                        <p class="card-text">₱5,100 per night</p>
                        <p class="text-danger">NOT AVAILABLE</p>
                        <button class="btn btn-warning mt-2" data-toggle="modal" data-target="#roomModal3">Book Now</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

   <!-- Room Details Modal -->
<div class="modal fade" id="roomModal" tabindex="-1" aria-labelledby="roomModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="roomModalLabel">Standard Double Room</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <!-- Left column for image carousel -->
                    <div class="col-md-5">
                        <div id="roomCarousel"  class="carousel slide mb-3" data-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="images/double.jpg" class="d-block w-100"  alt="Room Image 1">
                                </div>
                                <div class="carousel-item">
                                    <img src="images/3.jpg" class="d-block w-100" alt="Room Image 2">
                                </div>
                                <div class="carousel-item">
                                    <img src="images/4.jpg" class="d-block w-100" alt="Room Image 3">
                                </div>
                            </div>
                            <a class="carousel-control-prev" href="#roomCarousel" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#roomCarousel" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>                        
                    </div>
                    <form action="roompayment.php" method="post">
    <div class="contents col-md-7">
        <h3 name="room_name">Standard Double Room</h3>
        <p>2 Single Beds</p>
        <div class="mb-3">
            <p name="price"><strong>₱ 3,600 for 1 night</strong></p>
        </div>
        <div class="mb-2">
            <span class="badge bg-primary">Air Conditioning</span>
            <span class="badge bg-success">Private Bathroom</span>
            <span class="badge bg-warning">Flat-screen TV</span>
            <span class="badge bg-info">Free Wi-Fi</span>
            <span class="badge bg-danger">No Smoking</span>
        </div>
        <p>
            The double room features air conditioning, tumble dryer, a private bathroom, a shower, and a bidet. This room has tiled floors and a flat-screen TV.
        </p>
        <ul>
            <li>Shower</li>
            <li>Toilet</li>
            <li>Desk</li>
            <li>Flat-screen TV</li>
            <li>Tile/marble floor</li>
            <li>Air conditioning</li>
            <li>Free bottled water</li>
        </ul> 
        </div>                                     

        <form action="roompayment.php"  method="POST">
    <!-- Check-in and Check-out form -->
     <div class ="form-content">
    <div class="form-row" id="message-section">
        <label for="message" class="col-md-4">Message:</label>
        <textarea class="form-control" id="message" name="message" placeholder="Enter any special requests here..."></textarea>
    </div>
    </div>
    <button type="submit" class="btn btn-warning mt-3" id="reserveBtn"  >Reserve Room</button>
</form>


                    </div>
                </div>
            </div>
        </div>
    </div>
      <!-- Room Details Modal -->
<div class="modal fade" id="roomModal2" tabindex="-1" aria-labelledby="roomModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="roomModalLabel">Family Room</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <!-- Left column for image carousel -->
                    <div class="col-md-5">
                        <div id="roomCarousel"  class="carousel slide mb-3" data-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="images/4.jpg" class="d-block w-100"  alt="Room Image 1">
                                </div>
                                <div class="carousel-item">
                                    <img src="images/5.jpg" class="d-block w-100" alt="Room Image 2">
                                </div>
                                <div class="carousel-item">
                                    <img src="images/5.jpg" class="d-block w-100" alt="Room Image 3">
                                </div>
                            </div>
                            <a class="carousel-control-prev" href="#roomCarousel" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#roomCarousel" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>                        
                    </div>
                    <form action="roompayment.php" method="post">
    <div class="contents col-md-7">
        <h3 name="room_name">Family Room</h3>
        <p>2 Single Beds</p>
        <div class="mb-3">
            <p name="price"><strong>₱ 3,600 for 1 night</strong></p>
        </div>
        <div class="mb-2">
            <span class="badge bg-primary">Air Conditioning</span>
            <span class="badge bg-success">Private Bathroom</span>
            <span class="badge bg-warning">Flat-screen TV</span>
            <span class="badge bg-info">Free Wi-Fi</span>
            <span class="badge bg-danger">No Smoking</span>
        </div>
        <p>
            The double room features air conditioning, tumble dryer, a private bathroom, a shower, and a bidet. This room has tiled floors and a flat-screen TV.
        </p>
        <ul>
            <li>Shower</li>
            <li>Toilet</li>
            <li>Desk</li>
            <li>Flat-screen TV</li>
            <li>Tile/marble floor</li>
            <li>Air conditioning</li>
            <li>Free bottled water</li>
        </ul> 
        </div>                                     

        <form action="roompaymentfinals.php"  method="POST">
    <!-- Check-in and Check-out form -->
     <div class ="form-content">
    <div class="form-row" id="message-section">
        <label for="message" class="col-md-4">Message:</label>
        <textarea class="form-control" id="message" name="message" placeholder="Enter any special requests here..."></textarea>
    </div>
    <div class="form-row">
        <label for="meal" class="col-md-4">Free Meal:</label>
        <select class="form-control" id="meal" name="meal" required>
            <option value="">Choose Meal</option>
            <option value="breakfast">Breakfast</option>
            <option value="lunch">Lunch</option>
            <option value="dinner">Dinner</option>
            <option value="none">No Meal</option>
        </select>
    </div>
    </div>
    <button type="submit" class="btn btn-warning mt-3" id="reserveBtn">Reserve Room</button>
</form>


                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
</body>
</html>