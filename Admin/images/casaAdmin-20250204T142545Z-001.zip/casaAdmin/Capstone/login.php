<?php require 'db_con.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="home.css">
    <style>
     body {
            font-family: 'Arial', sans-serif;
            background-image: url('images/bg.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
        }


        .navbar {
            border-bottom: 2px solid white;
        }
        
        h3, .navbar-brand {
            font-family: "Playfair Display", serif;
            font-size: 20px;
            font-weight: 600;
        }

        .title {
            font-family: "Playfair Display", serif;
            font-size: 36px;
            font-weight: 900;
            color: #d4af37;
            text-align: center;
            margin: 0;
        }

        .subtitle {
            font-family: "Playfair Display", serif;
            font-size: 16px;
            font-weight: 600;
            color: #d4af37;
            text-align: center;
            margin-top: -10px;
            text-decoration: underline;
        }

        .form-title {
            font-size: 30px;
            color: #d4af37;
            text-align: center;
            margin-top: 20px;
        }

        h2, .form-title {
            font-family: "Playfair Display", serif;
        }
        .login-form{    
            width: 500px;
        }

        .card {
            border-radius: 15px;
            border: 2px solid #d4af37;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .btn-warning {
            background-color: #d4af37;
            border: none;
            font-weight: bold;
        }

        .btn-warning:hover {
            background-color: #c19a32;
        }

        .form-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }

        .form-container {
            width: 100%;
            
            max-width: 600px;
            margin-bottom: 40px;
            
        }
        @media (max-width: 768px) {
            .form-wrapper {
                flex-direction: column;
            }
        }

        nav ul {
            list-style: none;
            padding: 0;
            display: flex;
            flex-direction: row;
            gap: 10px;
        }

        nav a {
            text-decoration: none;
            color: black;
            padding: 5px 10px;
            transition: background-color 0.3s, color 0.3s;
        }

        nav a:hover {
            background-color: #856f11;
            color: white;
            border-radius: 10px;
        }

        .form-toggle {
            cursor: pointer;
            color: #d4af37;
            text-decoration: underline;
        }
        
    </style>

</head>
<body>
    
<div class="container mt-5 login-form" id="loginForm">
    <div class="form-wrapper">
        <div class="form-container col-md-6">
            <div class="card shadow p-4">
                <h1 class="title">CASA ESTELA</h1>
                <h2 class="subtitle">BOUTIQUE HOTEL & CAFE</h2>
                <h2 class="form-title">Log In</h2>

                <!-- Display login errors -->
                <?php if (isset($loginError)): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($loginError); ?></div>
                <?php endif; ?>

                <form action="logins.php" method="post">
                    <div class="mb-3">
                        <label for="loginUsername" class="form-label">Username or Email</label>
                        <input type="text" class="form-control" id="loginUsername" name="username" required placeholder="Enter your username">
                    </div>
                    <div class="mb-3">
                        <label for="loginPassword" class="form-label">Password</label>
                        <input type="password" class="form-control" id="loginPassword" name="password" required placeholder="Enter your password">
                    </div>
                    <button type="submit" name="loginUser" class="btn btn-warning w-100">Log In</button>
                </form>

                <p class="mt-3 text-center">Don't have an account? <span class="form-toggle" id="signupToggle" onclick="location.href='signup.php';">Sign Up</span></p>
            </div>
        </div>
    </div>
</div>

    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
