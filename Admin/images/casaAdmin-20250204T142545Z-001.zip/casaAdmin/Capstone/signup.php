<?php require 'db_con.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign-Up & Login Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
         body {
            font-family: 'Arial', sans-serif;
            background-color: white;
            background-image: url('images/bg.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }

        .title {
            font-family: "Playfair Display", serif;
            font-size: 36px;
            font-weight: 900;
            color: #d4af37;
            text-align: center;
            margin: 0;
        }

        .subtitle {
            font-family: "Playfair Display", serif;
            font-size: 16px;
            font-weight: 600;
            color: #d4af37;
            text-align: center;
            margin-top: -10px;
            text-decoration: underline;
        }

        .form-title {
            font-size: 30px;
            color: #d4af37;
            text-align: center;
            margin-top: 20px;
        }

        h2, .form-title {
            font-family: "Playfair Display", serif;
        }

        .card {
            border-radius: 15px;
            border: 2px solid #d4af37;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .btn-warning {
            background-color: #d4af37;
            border: none;
            font-weight: bold;
        }

        .btn-warning:hover {
            background-color: #c19a32;
        }

        .form-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }

        .form-container {
            width: 100%;
            max-width: 600px;
            margin-bottom: 40px;
            margin-top: 40px;
            background: none;
            border: none;
            background-color: rgba(255, 255, 255, 0.226);
            backdrop-filter: blur(3px);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        a {
            text-decoration: underline;
            color: blue;
        }
        .modal-body {
      font-family: Arial, sans-serif;
    }
    .modal-body p {
      margin-bottom: 1rem;
    }
    .modal-title{
        font-family: 'Playfair Display', serif;
        color: #d4af37;
        text-align: center;
    }
    h5{
        font-family: 'Playfair Display', serif;
        color: #d4af37;
    }
    .privacy-box {
      border: 1px solid #d4af37;
      padding: 15px;
      border-radius: 10px;
      background: #fdfdfd;
    }
    .privacy-box h5 {
      text-align: center;
      font-weight: bold;
      color: #000;
    }
    .privacy-box ul {
      margin-top: 1rem;
      list-style: none;
      padding: 0;
    }
    .privacy-box ul li {
      padding-left: 15px;
      text-indent: -15px;
    }
    .privacy-box ul li::before {
      content: "•";
      padding-right: 10px;
      color: #000;
    }
    .modal-footer{
        font-family: 'Playfair Display', serif;
        color: #d4af37;-
        text-align: center;
    }
    
    
        @media (max-width: 768px) {
            .form-wrapper {
                flex-direction: column;
            }
        

        .form-toggle {
            cursor: pointer;
            color: #d4af37;
            text-decoration: underline;
        }
        .login-form {
            display: none;
        }
        }
    </style>
</head>
<body>

     <!-- Navigation Bar -->

    <!-- Sign-Up Form -->
    <div class="container mt-5" id="signUpForm">
        <div class="form-wrapper">
            <div class="form-container col-md-6">
                <div class="card shadow p-4">
                    <h1 class="title">CASA ESTELA</h1>
                    <h2 class="subtitle">BOUTIQUE HOTEL & CAFE</h2>
                    <h2 class="form-title">Sign Up!</h2>
                    <form action= "singup.php" method="post">
                        <div class="mb-3 row rows">
                            <div class="col-md-6">
                                <label for="firstName" class="form-label">First Name*</label>
                                <input type="text" class="form-control" id="firstname" name="firstname" required placeholder="Enter your first name">
                            </div>
                            <div class="col-md-6">
                            <label for="lastName" class="form-label">Last Name*</label>
                                <input type="text" class="form-control" id="lastmame" name="lastname" required placeholder="Enter your last name">
                            </div>
                        </div>
                        
                        <div class="mb-3 row rows">
                            <div class="col-md-6">
                                <label for="email" class="form-label">Email*</label>
                                <input type="email" class="form-control" id="email" name="email" required placeholder="Enter your email">
                            </div>
                            <div class="col-md-6">
                                <label for="phone" class="form-label">Phone Number*</label>
                                <input type="number" class="form-control" id="contactnum" name="contactnum" required placeholder="Enter your phone number">
                            </div>
                        </div>
                        <div class="mb-3 row rows">
                            <div class="col-md-6">
                                <label for="username" class="form-label">Username*</label>
                                <input type="text" class="form-control" id="username" name="username" required placeholder="Enter your username">
                            </div>
                            <div class="col-md-6">
                                <label for="address" class="form-label">Address*</label>
                                <input type="text" class="form-control" id="address" name="address" required placeholder="Enter your address">
                            </div>
                        </div>
                        <div class="mb-3 row rows ">
                            <div class="col-md-6">
                                <label for="password" class="form-label">Password*</label>
                                <input type="password" class="form-control" id="password" name="password" required placeholder="Enter your password">
                            </div>
                            <div class="col-md-6">
                                <label for="confirmPassword" class="form-label">Confirm Password*</label>
                                <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" required placeholder="Re-type your password">
                            </div>
                        </div>
                        <div class="form-check mb-3">
                            <input type="checkbox" class="form-check-input" id="rememberMe">
                            <label class="form-check-label" for="rememberMe">Remember Me</label>
                        </div>
                        <div id="alertPlaceholder" class="mt-3"></div>
                        <button type="submit" name="insertUsers" class="btn btn-warning w-100" id="signupButton">
                            <span id="signupSpinner" class="spinner-border spinner-border-sm me-2" style="display: none;" role="status" aria-hidden="true"></span>
                            Sign Up
                        </button>
                        
                        </form>

                        <p class="mt-3 text-center">By signing in or creating an account, you agree with our 
                        <a href="#termsModal" data-bs-toggle="modal">Terms & conditions</a> and <a href="#privacyModal"data-bs-toggle="modal">Privacy statement</a>.

                    </p>
                    <p class="text-center">Already have an account? <span class="form-toggle" id="loginToggle" onclick="location.href='login.php';">Log In</span></p>
                        </div>
                    
                </div>
            </div>
        </div>
    </div> 
    
    <div class="modal fade" id="privacyModal" tabindex="-1" aria-labelledby="privacyModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="privacyModalLabel">Privacy Statement</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="privacy-box">
            <h5>Casa Estela Boutique Hotel & Café</h5>
            <p>
              This Privacy Policy outlines how we collect, use, and protect your information when you use our website and services.
              By accessing our website, you agree to the practices described below:
            </p>
            <ul>
              <li>We may collect personal information, including your name, contact details (email, phone number), and payment information.</li>
              <li>We collect website usage data such as IP addresses, browser types, and pages visited for performance improvement.</li>
              <li>Personal information helps us confirm bookings and provide services.</li>
              <li>We use the data to send updates, respond to inquiries, and improve user experience.</li>
              <li>Your data may be shared with trusted providers to help operate our services, under strict confidentiality.</li>
              <li>Information may be disclosed if required by law or to protect rights and safety.</li>
              <li>You have the right to request access, correction, or deletion of your personal information. Contact us at <a href="#">casaestelahotelcafe@gmail.com.</a></li>
              <li>Policy updates will be posted, and continued use implies acceptance of updated terms.</li>
            </ul>
            <p class="text-center">© Casa Estela. All Rights Reserved 2024</p>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="termsModal" tabindex="-1" aria-labelledby="termsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="termsModalLabel">Terms & Conditions</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="privacy-box">
            <h5>Casa Estela Boutique Hotel & Café</h5>
            <p>Welcome to Casa Estela Boutique Hotel & Café's website. By using our website, you agree to these Terms and Conditions. Please review them carefully:</p>
          <ul>
            <li>You agree to use the website for personal, non-commercial purposes only.</li>
            <li>All information and content on this website are provided for general informational purposes only.</li>
            <li>Reservations for rooms and café services must be made through our booking system.</li>
            <li>Guests are required to provide accurate information during the booking process.</li>
            <li>Cancellations can be made at any time; however, no refunds will be issued for canceled bookings.</li>
            <li>Refunds are not applicable under any circumstances for cancellations.</li>
            <li>Guests are expected to follow Casa Estela’s house rules during their stay, which will be provided upon check-in.</li>
            <li>We respect your privacy. Please review our <a href="#" class="text-primary text-decoration-underline">Privacy Policy</a> to understand how we collect, use, and protect your information.</li>
            <li>Casa Estela reserves the right to modify these Terms and Conditions at any time. Changes will be posted on this page.</li>
          </ul>
            <p class="text-center">© Casa Estela. All Rights Reserved 2024</p>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.querySelector('form').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent immediate form submission

    const signupButton = document.getElementById('signupButton');
    const signupSpinner = document.getElementById('signupSpinner');
    const alertPlaceholder = document.getElementById('alertPlaceholder');

    // Show the spinner and disable the button
    signupSpinner.style.display = 'inline-block';
    signupButton.disabled = true;

    // Form data
    const formData = new FormData(event.target);

    // Send the form data to the server
    fetch('singup.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json()) // Parse the JSON response from the server
    .then(data => {
        signupSpinner.style.display = 'none'; // Hide the spinner
        signupButton.disabled = false; // Enable the button

        if (data.status === 'success') {
            // Show success alert
            alertPlaceholder.innerHTML = 
                `<div class="alert alert-success alert-dismissible fade show" role="alert">
                    ${data.message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>`;

            // Optionally, redirect after a delay
            setTimeout(() => {
                window.location.href = 'login.php'; // Redirect to login page
            }, 2000); // Redirect after 2 seconds
        } else {
            // Show error alert
            alertPlaceholder.innerHTML = 
                `<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    ${data.message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>`;
        }
    })
    .catch(error => {
        signupSpinner.style.display = 'none'; // Hide the spinner
        signupButton.disabled = false; // Enable the button
        alertPlaceholder.innerHTML = 
            `<div class="alert alert-danger alert-dismissible fade show" role="alert">
                Something went wrong. Please try again later.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>`;
    });
});



// Handle login and sign-up toggle
document.getElementById('loginToggle').addEventListener('click', function() {
    document.getElementById('signUpForm').style.display = 'none';  
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('forgotPasswordForm').style.display = 'none';
});

document.getElementById('signupToggle').addEventListener('click', function() {
    document.getElementById('loginForm').style.display = 'none';  
    document.getElementById('signUpForm').style.display = 'block';
    document.getElementById('forgotPasswordForm').style.display = 'none';
});

document.getElementById('forgotPasswordToggle').addEventListener('click', function() {
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('forgotPasswordForm').style.display = 'block';
});

document.getElementById('backToLoginToggle').addEventListener('click', function() {
    document.getElementById('forgotPasswordForm').style.display = 'none';
    document.getElementById('loginForm').style.display = 'block';
});

</script>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>