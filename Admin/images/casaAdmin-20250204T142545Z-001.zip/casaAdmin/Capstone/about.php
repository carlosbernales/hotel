<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Casa Estela - About Us</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            top: 100px;
            padding: 0;
            background-color: #f5f5f5;
        }

        header {
            background-color: #d4af37;
            text-align: center;
            padding: 1rem 0;
            color: #fff;
        }

        header .navbar h1 {
            font-size: 2rem;
            margin: 0;
        }

        header .navbar .tagline {
            font-style: italic;
            font-size: 1rem;
            margin: 0;
        }

        /* About Us Section */
        .about-us {
            padding: 2rem;
            background-color: #fff;
            max-width: 1200px;
            height: auto;
            margin-top: 100px;
            margin: 2rem auto;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .about-us-container {
            display: flex;
            flex-wrap: wrap;
            gap: 2rem;
            justify-content: center;
        }

        .about-us-image {
            flex: 1;
            max-width: 500px;
            min-width: 300px;
        }

        .about-us-image img {
            width: 100%;
            height: auto;
            box-shadow: 0 9px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            object-fit: cover;
        }

        .about-us-content {
            flex: 1;
            max-width: 600px;
            min-width: 300px;
        }

        .about-us-content h2 {
            color: #d4af37;
            text-align: center;
            margin: 5px;
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }

        .about-us-content p {
            margin-left: 20px;
            color: #333;
            line-height: 1.6;
            font-size: 20px;
            box-shadow: 0 9px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 1rem;
        }

        .learn-more {
            display: inline-block;
            background-color: #d4af37;
            color: #fff;
            padding: 10px;
            align-items: center;
            margin-left: 270px;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .learn-more:hover {
            background-color: #b8902b;
        }

        /* Media Queries for Responsiveness */
        @media (max-width: 568px) {
            .about-us-container {
                flex-direction: column;
                align-items: center;
            }

            .about-us-content {
                margin-left: 0;
                text-align: center;
            }

            .learn-more {
                margin-left: 0;
                display: block;
                width: 100px;
                margin-left: 200px;
                text-align: center;
                margin-top: 20px;
            }
        }

        @media (max-width: 930px) {
            header .navbar h1 {
                font-size: 1.5rem;
            }

            header .navbar .tagline {
                font-size: 0.9rem;
            }

            .about-us-content p {
                font-size: 18px;
            }

            .learn-more {
                margin-left: 0;
                padding: 8px;
            }
        }

    </style>
</head>
<?php include ('nav.php'); ?>
<body>
    <main>

        <section class="about-us">
            <div class="about-us-container">
                <div class="about-us-image">
                    <img src="images/bg.jpg" alt="Casa Estela Building">
                </div>
                <div class="about-us-content">
                    <h2>About Casa Estela</h2>
                    <p>
                        Welcome to Casa Estela, where comfort meets elegance. Located in the heart of the city, 
                        our boutique hotel offers a tranquil retreat with modern amenities. Whether you're here 
                        for business or leisure, our team is dedicated to making your stay unforgettable. 
                        Experience warm hospitality and enjoy a home away from home. Welcome to Casa Estela, where comfort meets elegance. Located in the heart of the city, 
                        our boutique hotel offers a tranquil retreat with modern amenities. Whether you're here 
                        for business or leisure, our team is dedicated to making your stay unforgettable. 
                        Experience warm hospitality and enjoy a home away from home.
                    </p>
                </div>
            </div>
        </section>
    </main>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
