<?php
require 'db_con.php';
session_start();

// Check if the user is logged in
if (!isset($_SESSION['userid'])) {
    header('location:login.php');
    exit();
}

$userid = $_SESSION['userid'];

$select_profile = $pdo->prepare("SELECT * FROM `users` WHERE userid = ?");
$select_profile->execute([$userid]);
$fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);

if (!$fetch_profile) {
    header('location:login.php');
    exit();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Management</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<style>

    .profile-img {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        object-fit: cover;
    }
</style>
<body>
     <!-- Navigation Bar -->
 <?php include('nav.php'); ?>

<div class="container mt-5">
    <h2 class="text-center mb-4">Manage Account</h2>
    <div class="card p-4">
        <div class="row">
                <div class="col-md-4 text-center">
            <img src="images/<?php echo htmlspecialchars($fetch_profile['profile_photo']); ?>" 
                alt="Profile Image" class="profile-img border border-secondary">
        </div>

            <div class="col-md-8">
                <table class="table">
                    <tr>
                        <td><strong>First Name:</strong></td>
                        <td><?php echo htmlspecialchars($fetch_profile['firstname']); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Username:</strong></td>
                        <td><?php echo htmlspecialchars($fetch_profile['username']); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Email:</strong></td>
                        <td><?php echo htmlspecialchars($fetch_profile['email']); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Contact Number:</strong></td>
                        <td><?php echo htmlspecialchars($fetch_profile['contactnum']); ?></td>
                    </tr>
                </table>
                <button class="btn btn-primary" data-toggle="modal" data-target="#editModal">Edit Details</button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <form action="update_account.php" method="POST" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Account Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <input type="hidden" name="userid" value="<?php echo $fetch_profile['userid']; ?>">

                    <table class="table">
                        <tr>
                            <td><strong>First Name:</strong></td>
                            <td>
                                <input type="text" name="firstname" value="<?php echo htmlspecialchars($fetch_profile['firstname']); ?>" class="form-control" required>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Username:</strong></td>
                            <td>
                                <input type="text" name="username" value="<?php echo htmlspecialchars($fetch_profile['username']); ?>" class="form-control" required>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Email:</strong></td>
                            <td>
                                <input type="email" name="email" value="<?php echo htmlspecialchars($fetch_profile['email']); ?>" class="form-control" required>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Contact Number:</strong></td>
                            <td>
                                <input type="text" name="contactnum" value="<?php echo htmlspecialchars($fetch_profile['contactnum']); ?>" class="form-control" required>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Password:</strong></td>
                            <td>
                                <input type="password" name="password" class="form-control">
                                <small>Leave blank to keep the current password.</small>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Profile Photo:</strong></td>
                            <td>
                                <input type="file" name="profile_photo" class="form-control">
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css">

</body>
</html>
