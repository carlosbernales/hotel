<?php
require_once 'db_con.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['userid'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'])) {
    $orderId = $_POST['order_id'];

    try {
        // Update the order status to 'Cancelled'
        $stmt = $pdo->prepare("UPDATE orders SET status = 'Cancelled' WHERE order_id = :order_id AND userid = :userid");
        $stmt->execute([':order_id' => $orderId, ':userid' => $_SESSION['userid']]);

        // Redirect back to the orders page
        header('Location: myorders.php?cancel=success');
    } catch (PDOException $e) {
        die('Error updating order status: ' . $e->getMessage());
    }
}
?>
