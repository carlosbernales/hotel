<?php require 'db_con.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Website Homepage</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="home.css">
</head>
<body>

 <!-- Navigation Bar -->
 <nav class="navbar navbar-expand-lg navbar-light bg-warning">
    <div class="container">
        <h3 class="navbar-brand">E-Akomoda</h3>

        <!-- Notification and Message Icons (Always Visible on Mobile) -->
        <div class="d-lg-none d-flex align-items-center">
            <a href="#" class="nav-link notification-icon">
                <i class="fas fa-bell"></i>
            </a>
            <a href="#" class="nav-link notification-icon">
                <i class="fas fa-envelope"></i>
            </a>         
        </div>

      

        <!-- Toggler Button for Mobile -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Collapsible Menu -->
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="login.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="login.php">Rooms</a></li>
                <li class="nav-item"><a class="nav-link" href="login.php">Café</a></li>
                <li class="nav-item"><a class="nav-link" href="login.php">Events</a></li>
                <li class="nav-item"><a class="nav-link" href="login.php">About Us</a></li>
                <li class="nav-item"><a class="nav-link" href="login.php">Contact Us</a></li>
                <li class="nav-item"><a class="nav-link" href="login.php">log in</a></li>

                <!-- Notification and Message Icons (Visible Only on Desktop) -->
                <li class="nav-item d-none d-lg-inline-block">
                    <a href="#" class="nav-links notification-icon">
                        <i class="fas fa-bell"></i>
                    </a>
                </li>
                <li class="nav-item d-none d-lg-inline-block">
                    <a href="#" class="nav-link notification-icon">
                        <i class="fas fa-envelope"></i>
                    </a>
                </li>

                <!-- Log Out Dropdown for Desktop -->
                <li class="nav-item dropdown d-none d-lg-inline-block">
                    <a class="nav-link dropdown-toggle" href="#" id="logoutDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Log Out <i class="fas fa-sign-out-alt"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="logoutDropdown">
                        <li>
                            <div class="dropdown-item text-center">
                                <img src="images/bg.jpg" alt="Profile Image" class="img-fluid rounded-circle" style="width: 100px; height: 100px;">
                            </div>
                        </li>
                        <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
                        <li><a class="dropdown-item" href="reservstion.html">Bookings Reservation</a></li>
                        <li><a class="dropdown-item" href="#">My Orders</a></li>
                        <li><a class="dropdown-item" href="logout.php">Log Out</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Welcome Section -->

<section class="container mt-5">
    <div class="titles">
    <h3 class="title1">CASA </h3>
    <h1 class="title"> ESTELA</h1>
    <h2 class="subtitle">BOUTIQUE HOTEL & CAFE</h2>
</div>
    <div class="text-center mb-4">
        <marquee behavior="scroll" direction="left">Welcome to Casa Estela Boutique Hotel and Café, where luxury meets comfort.</marquee>
    </div>

    <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="images/bg.jpg" class="d-block w-100 carousel-image" alt="Image 1">
                <div class="carousel-caption d-none d-md-block">
                    <button class="btn btn-warning">Get Started</button>
                </div>
            </div>
            <div class="carousel-item">
                <img src="images/bg.jpg" class="d-block w-100 carousel-image" alt="Image 2">
                <div class="carousel-caption d-none d-md-block">
                    <button class="btn btn-warning">Get Started</button>
                </div>
            </div>
            <div class="carousel-item">
                <img src="images/bg.jpg" class="d-block w-100 carousel-image" alt="Image 3">
                <div class="carousel-caption d-none d-md-block">
                    <button class="btn btn-warning">Get Started</button>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    
</section>
<p   class="paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<div class="container mt-5">
    <div class="row">
    <div class="container mt-5">
    <div class="row">
        <!-- First Carousel on the Left -->
        <div class="col-md-6">
            <div id="carouselLeft" class="carousel slide" data-ride="carousel" data-interval="3000">
                <ol class="carousel-indicators">
                    <li data-target="#carouselLeft" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselLeft" data-slide-to="1"></li>
                    <li data-target="#carouselLeft" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img class="d-block w-100" src="images/bg.jpg" alt="First slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" src="images/bg.jpg" alt="Second slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" src="images/bg.jpg" alt="Third slide">
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselLeft" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselLeft" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>

        <!-- Second and Third Carousels on the Right -->
        <div class="col-md-6">
            <!-- Second Carousel (Top Right) -->
            <div id="carouselTopRight" class="carousel slide mb-4" data-ride="carousel" data-interval="3000">
                <ol class="carousel-indicators">
                    <li data-target="#carouselTopRight" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselTopRight" data-slide-to="1"></li>
                    <li data-target="#carouselTopRight" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img class="d-block w-100" src="images/bg.jpg" alt="First slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" src="images/bg.jpg" alt="Second slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" src="images/bg.jpg" alt="Third slide">
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselTopRight" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselTopRight" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>

            <!-- Third Carousel (Bottom Right) -->
            <div id="carouselBottomRight" class="carousel slide" data-ride="carousel" data-interval="3000">
                <ol class="carousel-indicators">
                    <li data-target="#carouselBottomRight" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselBottomRight" data-slide-to="1"></li>
                    <li data-target="#carouselBottomRight" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img class="d-block w-100" src="images/bg.jpg" alt="First slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" src="images/bg.jpg" alt="Second slide">
                    </div>
                    <div class="carousel-item">
                        <img class="d-block w-100" src="images/bg.jpg" alt="Third slide">
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselBottomRight" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselBottomRight" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</div>

<section class="container section-box">
    <h3 class="section-title text-center">Casa Estela Boutique Hotel and Café Facilities</h3>
    <div class="row">
        <div class="col-md-4">
            <h5 class="facility-category">Parking</h5>
            <ul class="facilities-list">
                <li>Free private parking spaces</li>
                <li>Valet parking</li>
                <li>Parking garage</li>
                <li>Accessible parking</li>
            </ul>
            <h5 class="facility-category">Bathroom</h5>
            <ul class="facilities-list">
                <li>Toilet paper</li>
                <li>Bidet</li>
                <li>Slippers</li>
                <li>Private bathroom</li>
                <li>Toilet</li>
                <li>Hairdryer</li>
                <li>Shower</li>
            </ul>
        </div>
        
        <div class="col-md-4">
            <h5 class="facility-category">Safety & Security</h5>
            <ul class="facilities-list">
                <li>Fire extinguishers</li>
                <li>CCTV</li>
                <li>Smoke alarms</li>
                <li>Security alarm</li>
                <li>Key card access</li>
                <li>24-hour security</li>
            </ul>
            <h5 class="facility-category">Languages Spoken</h5>
            <ul class="facilities-list">
                <li>English</li>
                <li>Filipino</li>
            </ul>
        </div>
        
        <div class="col-md-4">
            <h5 class="facility-category">Food & Drink</h5>
            <ul class="facilities-list">
                <li>Coffee house</li>
                <li>Snack bar</li>
                <li>Restaurant</li>
            </ul>
            <h5 class="facility-category">Reception Services</h5>
            <ul class="facilities-list">
                <li>Private check-in/check-out</li>
                <li>Luggage storage</li>
                <li>24-hour front desk</li>
            </ul>
            <h5 class="facility-category">Internet</h5>
            <ul class="facilities-list">
                <li>Free Wi-Fi</li>
            </ul>
        </div>
    </div>
</section>

<!-- Hotel Policy Section -->
<section class="container section-box">
    <h3 class="section-title">Hotel Policy</h3>
    <ul class="policy-list">
        <li>Check-in: Anytime</li>
        <li>Check-out: Anytime</li>
        <li>Smoking is not permitted inside the hotel premises. Designated smoking areas are available outside.</li>
        <li>Pets are not allowed.</li>
        <li>We accept cash, major credit cards, and mobile payment options.</li>
        <li>We expect all guests to treat our staff and other guests with respect.</li>
        <li>Guests may cancel their reservation at any time; however, payments already made will not be refunded.</li>
    </ul>
</section>
<div class="footer"> @E-CasaLink Alright Reserved 2024</div>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Bootstrap Icons (Optional) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

<!-- Bootstrap JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        
    </body>
</html>
