<?php
require_once 'db_con.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['userid'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['userid'];
$startDate = isset($_POST['start_date']) ? $_POST['start_date'] : '';
$endDate = isset($_POST['end_date']) ? $_POST['end_date'] : '';

try {
    $query = "
        SELECT o.order_id, o.payment_method, o.total_price, o.created_at, o.status,
               oi.item_name, oi.category, oi.price, oi.qty, oi.addons
        FROM orders o
        JOIN order_items oi ON o.order_id = oi.order_id
        WHERE o.userid = :userid";

    if ($startDate && $endDate) {
        $query .= " AND o.created_at BETWEEN :startDate AND :endDate";
    }
    
    $query .= " ORDER BY o.created_at DESC";

    $stmt = $pdo->prepare($query);
    $params = [':userid' => $userId];
    
    if ($startDate && $endDate) {
        $params[':startDate'] = $startDate;
        $params[':endDate'] = $endDate;
    }

    $stmt->execute($params);

    $orders = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $orderId = $row['order_id'];
        if (!isset($orders[$orderId])) {
            $orders[$orderId] = [
                'order_id' => $orderId,
                'payment_method' => $row['payment_method'],
                'total_price' => $row['total_price'],
                'created_at' => $row['created_at'],
                'status' => $row['status'],
                'items' => []
            ];
        }
        $orders[$orderId]['items'][] = [
            'item_name' => $row['item_name'],
            'category' => $row['category'],
            'price' => $row['price'],
            'qty' => $row['qty'],
            'addons' => json_decode($row['addons'], true)
        ];
    }
} catch (PDOException $e) {
    die('Error fetching orders: ' . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .text-center{
            padding-top: 70px;
        }
        .date-range-form{
            padding-bottom: 20px;
            align-items: center;
        }
        .cancel-btn {
            display: block;
            width: 100%;
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .cancel-btn:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }

        .cancel-btn.animate-pulse {
            animation: pulse 1s infinite;
        }

        /* Pulse animation */
        @keyframes pulse {
            0% {
                transform: scale(1);
                box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
            }
            50% {
                transform: scale(1.1);
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            }
            100% {
                transform: scale(1);
                box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
            }
        }    
        .order-details {
            display: none;  /* Initially hidden */
            overflow: hidden;
            height: 0;
            transition: height 0.5s ease-out;  /* Smooth slide transition */
            margin-top: 15px;  /* Adds space between the order details and other elements */
        }

        .order-details.open {
            display: block;
            height: auto; 
        }

        .toggle-details {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .toggle-details:hover {
            background-color: gold;
        }

        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
    </style>
</head>
<body>
     <!-- Navigation Bar -->
 <?php include('nav.php'); ?>
    <div class="container">
        <h1 class="text-center mb-4">My Orders</h1>

        <div class="date-range-form">
            <form method="POST">
                <input type="date" name="start_date" value="<?= htmlspecialchars($startDate) ?>" class="form-control d-inline-block w-auto">
                <input type="date" name="end_date" value="<?= htmlspecialchars($endDate) ?>" class="form-control d-inline-block w-auto">
                <button type="submit" class="btn btn-primary">Filter by Date</button>
            </form>
        </div>

        <?php if (!empty($orders)): ?>
            <?php foreach ($orders as $order): ?>
                <div class="card" data-created-time="<?= htmlspecialchars($order['created_at']) ?>">
                    <div class="card-header order-header">
                        <span>Order ID: <?= htmlspecialchars($order['order_id']) ?></span>
                        <button class="toggle-details">Show Details</button>
                    </div>
                    <div class="order-details">
                        <div class="card-body">
                            <p><strong>Payment Method:</strong> <?= htmlspecialchars($order['payment_method']) ?></p>
                            <p><strong>Total Price:</strong> ₱<?= number_format($order['total_price'], 2) ?></p>
                            <p><strong>Order Date:</strong> <?= date('F d, Y h:i A', strtotime($order['created_at'])) ?></p>
                            <h5>Items:</h5>
                            <?php foreach ($order['items'] as $item): ?>
                                <div class="item">
                                    <p><strong>Name:</strong> <?= htmlspecialchars($item['item_name']) ?></p>
                                    <p><strong>Category:</strong> <?= htmlspecialchars($item['category']) ?></p>
                                    <p><strong>Quantity:</strong> <?= htmlspecialchars($item['qty']) ?></p>
                                    <p><strong>Price:</strong> ₱<?= number_format($item['price'], 2) ?></p>
                                    <p><strong>Add-ons:</strong>
                                        <?php if (!empty($item['addons'])): ?>
                                            <?= implode(', ', array_map(function ($addon) {
                                                return htmlspecialchars($addon['name']) . ' (₱' . number_format($addon['price'], 2) . ')';
                                            }, $item['addons'])) ?>
                                        <?php else: ?>
                                            None
                                        <?php endif; ?>
                                    </p>
                                </div>
                            <?php endforeach; ?>
                            <!-- Cancel Button -->
                            <?php if ($order['status'] !== 'Cancelled'): ?>
                                <form method="POST" action="cancel_order.php">
                                    <input type="hidden" name="order_id" value="<?= htmlspecialchars($order['order_id']) ?>">
                                    <button type="submit" class="cancel-btn" id="cancel-btn-<?= $order['order_id'] ?>">Cancel Order</button>
                                    <p>Time left to cancel: <span class="timer">5:00</span></p>
                                </form>

                            <?php else: ?>
                                <button class="cancel-btn" disabled>Cancelled</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="text-center">You have no orders yet.</p>
        <?php endif; ?>
    </div>

    <script>
document.addEventListener('DOMContentLoaded', () => {
    const orders = document.querySelectorAll('.card');

    // Toggle order details
    orders.forEach(order => {
        const orderHeader = order.querySelector('.order-header');
        const orderDetails = order.querySelector('.order-details');
        const toggleDetailsBtn = order.querySelector('.toggle-details');

        // Toggle visibility of order details
        toggleDetailsBtn.addEventListener('click', () => {
            orderDetails.classList.toggle('open');
            toggleDetailsBtn.textContent = orderDetails.classList.contains('open') ? 'Hide Details' : 'Show Details';
        });

        // Initialize timer for orders with active cancel buttons
        const timerElement = order.querySelector('.timer');
        const cancelBtn = order.querySelector('.cancel-btn');
        if (timerElement && cancelBtn && !cancelBtn.disabled) {
            let timeLeft = 5 * 60; // Set initial time in seconds (5 minutes)

            const updateTimer = () => {
                const minutes = Math.floor(timeLeft / 60);
                const seconds = timeLeft % 60;
                timerElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;

                if (timeLeft > 0) {
                    timeLeft--;
                } else {
                    // Disable cancel button when time expires
                    cancelBtn.disabled = true;
                    cancelBtn.textContent = 'Cancel Time Expired';
                    clearInterval(timerInterval);
                }
            };

            // Start the countdown timer
            const timerInterval = setInterval(updateTimer, 1000);
            updateTimer(); // Initialize display immediately
        }
    });

    // Handle cancel button clicks with confirmation dialog
    const cancelBtns = document.querySelectorAll('.cancel-btn');
    cancelBtns.forEach(btn => {
        btn.addEventListener('click', (event) => {
            const confirmation = confirm('Are you sure you want to cancel this order?');
            if (!confirmation) {
                // Prevent form submission if the user cancels
                event.preventDefault();
            } else {
                alert('Order cancelled successfully.');
            }
        });
    });
});


    </script>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
