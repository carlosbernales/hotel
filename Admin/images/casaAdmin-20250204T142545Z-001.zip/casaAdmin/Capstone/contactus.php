<?php
session_start();
require_once 'db_con.php'; // Include your PDO connection setup

header('Content-Type: application/json'); // Ensure JSON response

$response = [
    'success' => false,
    'message' => 'An unexpected error occurred.'
];

try {

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get and sanitize form data
        $name = htmlspecialchars($_POST['name']);
        $email = htmlspecialchars($_POST['email']);
        $message = htmlspecialchars($_POST['message']);

        if (isset($_SESSION['userid'])) {
            $userid = $_SESSION['userid']; 


            $stmt = $pdo->prepare("INSERT INTO contactus (userid, name, email, message) VALUES (:userid, :name, :email, :message)");
            $stmt->bindParam(':userid', $userid);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':message', $message);

            if ($stmt->execute()) {
                $response['success'] = true;
                $response['message'] = 'Your message has been sent successfully!';
            } else {
                $response['message'] = 'Failed to send your message. Please try again.';
            }
        } else {
            $response['message'] = 'You must be logged in to send a message.';
        }
    } else {
        $response['message'] = 'Invalid request method.';
    }
} catch (PDOException $e) {
    error_log('Database error: ' . $e->getMessage());
    $response['message'] = 'A database error occurred. Please try again later.';
} catch (Exception $e) {

    error_log('General error: ' . $e->getMessage());
    $response['message'] = 'An error occurred. Please try again later.';
}


echo json_encode($response);
