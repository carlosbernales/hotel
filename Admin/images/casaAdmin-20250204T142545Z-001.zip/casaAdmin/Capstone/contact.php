<?php
require 'db_con.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Casa Estela - Contact Us</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
   body {
        font-family: "Poppins", serif;
        font-weight: 200;
        font-style: normal;
         }
        .navbar {
            font-family: 'Playfair Display', serif;
            border-bottom: 2px solid white;
            width: 100%;
        }
        .navbar-brand {
            margin-right: 20px;
            font-size: 24px;
            font-family: 'Playfair Display', serif;   
        }
        .nav-link {
            color: black;
            font-weight: 900;
            padding: 10px;
        }
        .nav-link:hover {
            background-color: #856f11;
            color: white;
            border-radius: 5px;
        }
        .notification-icon {
            font-size:18px;
            position: relative;
            color: black;
        }
        .notification-icon .notification-badge {
            position: absolute;
            top: -5px;
            right: -10px;
            background: red;
            color: white;
            font-size: 10px;
            border-radius: 50%;
            padding: 2px 6px;
        }
        .nav-link .dropdown-toggle{
            margin-right: 10px;

        }
        .section-title{
            text-align: center;
            font-size: 30px;
            padding-bottom: 20px;
            color: #d4af37;
            text-align: center;
        }
        .contact-section{
            padding-top: 40px;
            width: 80%;
            border: 1px solid #d4af37;
            border-radius: 8px;
           
        }
        .navbar, .contact-section{
           margin-bottom: 20px;
        }
        .contact-form, .contact-section {
            padding: 30px;
        }
        .contact-info{
            margin-top: 50px;
            
        }
        .contact-info i {
            color: #8b5d12;
            font-size: 20px;
            padding-right: -5px;
            margin-left: 50px;
            top: 55px;
            
        }
        .contact-info a{
            color: #8b5d12;
            font-size: 20px;
            text-decoration: none;
            margin-top: 2px;
            margin-left: 10px
            
        }
        .footer {
            width: 100%;
            height: 28px;
            background-color:#d4af37;
            text-align: center;
            margin-top: 20px;
            border-radius: 8px;
        }


/* Optional: Adjust icon alignment for smaller screens */
@media (max-width: 576px) {
    .navbar {
        padding: 10px 20px; /* Adjust padding for mobile */
    }
    body{

        padding-top: 50px;
    }
    .navbar-brand {
        margin-right: auto;
    }

        .navbar {
            position: fixed; 
            top: 0;
            left: 0;
            width: 100%;   
            z-index: 1000; 
        }
        .notification-icon
        {
            font-size: 20px;
            margin: 0px 0px 0px 10px ;
        }
        .nav-item{
            color:black;
            font-size: 15px;
            margin-right: 10px;
            margin-bottom: 25px;
            
        }
        .section-title {
            font-size: 30px;
            color: #d4af37;
            text-align: center;
            margin: 10px 0;
        }
        .navbar, .contact-section{
           margin-bottom: 50px;
        }
        .contact-form, .contact-section {
            padding: 30px;
        }
        .contact-section {
            width: 95%;
            background-color: #ffffff;
            padding: 40px;
            border: 1px solid #d4af37;
            border-radius: 8px;
            margin: 20px;
        }
        .contact-form {
            margin-top: 20px;
            
        }
        .contact-info, .contact-form {
            margin-bottom: 20px;
        }
        .contact-info i {
            color: #8b5d12;
            font-size: 15px;
            padding: 5px;
            top: 30px;
            margin-left: 10px;
            
        }
        .contact-info a{
            color: #8b5d12;
            font-size: 15px;
            text-decoration: none;
            margin-top: 0px;
            margin-left: 10px;
            
        }
        .contact-form label {
            font-weight: bold;
        }
        .contact-form input, .contact-form textarea {
            border: 1px solid #d4af37;
            border-radius: 5px;
        }
        .submit-btn {
            background-color: #ffc107;
            color: #000;
            border: none;
            padding: 10px 20px;
            font-weight: bold;
        }
        .footer {
            width: 100%;
            height: 28px;
            background-color:#d4af37;
            text-align: center;
            margin-top: 20px;
            border-radius: 8px;
        }
    }
    @media (max-width: 782px) {
    .navbar {
        padding: 10px 20px; /* Adjust padding for mobile */
    }
    body{

        padding-top: 50px;
    }
    .navbar-brand {
        margin-right: auto;
    }

        .navbar {
            position: fixed; 
            top: 0;
            left: 0;
            width: 100%;   
            z-index: 1000; 
        }
        .notification-icon
        {
            font-size: 15px;
            margin: 0px 0px 0px 10px ;
        }
        .nav-item{
            color:black;
            font-size: 15px;
            margin-right: 10px;
            margin-bottom: 25px;
            
        }
        .section-title {
            font-size: 30px;
            color: #d4af37;
            text-align: center;
            margin: 10px 0;
        }
        .navbar, .contact-section{
           margin-bottom: 50px;
        }
        .contact-form, .contact-section {
            padding: 30px;
        }
        .contact-section {
            width: 95%;
            background-color: #ffffff;
            padding: 40px;
            font-size: 18px
            border: 1px solid #d4af37;
            border-radius: 8px;
            margin: 20px;
        }
        .contact-form {
            margin-top: 20px;
            margin-right: 20px;
            
        }
        .contact-info, .contact-form {
            margin-bottom: 20px;
        }
        .contact-info i {
            color: #8b5d12;
            font-size: 15px;
            padding: 5px;
            top: 30px;
            margin-left: 10px;
            
        }
        .contact-info a{
            color: #8b5d12;
            font-size: 15px;
            text-decoration: none;
            margin-top: 0px;
            margin-left: 10px;
            
        }
        .contact-form label {
            font-weight: bold;
        }
        .contact-form input, .contact-form textarea {
            border: 1px solid #d4af37;
            border-radius: 5px;
        }
        .submit-btn {
            background-color: #ffc107;
            color: #000;
            border: none;
            padding: 10px 20px;
            font-weight: bold;
        }
        .footer {
            width: 100%;
            height: 28px;
            background-color:#d4af37;
            text-align: center;
            margin-top: 20px;
            border-radius: 8px;
        }
    }
    @media (max-width: 1000px) {
    .navbar {
        padding: 10px 20px; /* Adjust padding for mobile */
    }
    body{

        padding-top: 50px;
    }
    .navbar-brand {
        margin-right: auto;
    }

        .navbar {
            position: fixed; 
            top: 0;
            left: 0;
            width: 100%;   
            z-index: 1000; 
        }
        .notification-icon
        {
            font-size: 15px;
            margin: 0px 0px 0px 10px ;
        }
        .nav-item{
            color:black;
            font-size: 15px;
            margin-right: 10px;
            margin-bottom: 25px;
            
        }
        .section-title {
            font-size: 30px;
            color: #d4af37;
            text-align: center;
            margin: 10px 0;
        }
        .navbar, .contact-section{
           margin-bottom: 50px;
        }
        .contact-form, .contact-section {
            padding: 30px;
        }
        .contact-section {
            width: 95%;
            background-color: #ffffff;
            padding: 40px;
            border: 1px solid #d4af37;
            border-radius: 8px;
            margin: 20px;
        }
        .contact-form {
            margin-top: 20px;
            
        }
        .contact-info, .contact-form {
            margin-bottom: 20px;
        }
        .contact-info i {
            color: #8b5d12;
            font-size: 15px;
            padding: 5px;
            top: 30px;
            margin-left: 10px;
            
        }
        .contact-info a{
            color: #8b5d12;
            font-size: 15px;
            text-decoration: none;
            margin-top: 0px;
            margin-left: 10px;
            
        }
        .contact-form label {
            font-weight: bold;
        }
        .contact-form input, .contact-form textarea {
            border: 1px solid #d4af37;
            border-radius: 5px;
        }
        .submit-btn {
            background-color: #ffc107;
            color: #000;
            border: none;
            padding: 10px 20px;
            font-weight: bold;
        }
        .footer {
            width: 100%;
            height: 28px;
            background-color:#d4af37;
            text-align: center;
            margin-top: 20px;
            border-radius: 8px;
        }
    }
    </style>
</head>
<body>

    <!-- Navigation Bar --><nav class="navbar navbar-expand-lg navbar-light bg-warning">
    <div class="container">
        <h3 class="navbar-brand">E-Akomoda</h3>

        <div class="d-lg-none d-flex align-items-center">
            <a href="#" class="nav-link notification-icon">
                <i class="fas fa-bell"></i>
            </a>
            <a href="#" class="nav-link notification-icon">
                <i class="fas fa-envelope"></i>
            </a>         
        </div>

        <li class="nav-item dropdown d-lg-none">
            <a class="nav-link dropdown-toggle" href="#" id="logoutDropdownMobile" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                My Profile <i class="fas fa-sign-out-alt"></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="logoutDropdownMobile">
                <li class="d-flex align-items-center">
                <i class="bi bi-person-fill"></i><a class="dropdown-item" href="profile.php">My Profile</a>
                </li>
                <li class="d-flex align-items-center">
                    <i class="fas fa-bookmark me-2"></i><a class="dropdown-item" href="reservations.php">Bookings Reservation</a>
                </li>
                <li class="d-flex align-items-center">
                    <i class="fas fa-box-open me-2"></i><a class="dropdown-item" href="myorders.php">My Orders</a>
                </li>
                <li class="d-flex align-items-center">
                    <i class="fas fa-comments me-2"></i><a class="dropdown-item" href="feedback.php">Feedback</a>
                </li>
                <li class="d-flex align-items-center">
                    <i class="fas fa-sign-out-alt me-2"></i><a class="dropdown-item" href="logout.php">Log Out</a>
                </li>
            </ul>
        </li>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="home.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="rooms.php">Rooms</a></li>
                <li class="nav-item"><a class="nav-link" href="cafes.php">Café</a></li>
                <li class="nav-item"><a class="nav-link" href="events.html">Events</a></li>
                <li class="nav-item"><a class="nav-link" href="about.html">About Us</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>

                <li class="nav-item d-none d-lg-inline-block">
                    <a href="#" class="nav-link notification-icon">
                        <i class="fas fa-bell"></i>
                    </a>
                </li>
                <li class="nav-item d-none d-lg-inline-block">
                    <a href="#" class="nav-link notification-icon">
                        <i class="fas fa-envelope"></i>
                    </a>
                </li>

                <!-- Log Out Dropdown for Desktop -->
                <li class="nav-item dropdown d-none d-lg-inline-block">
                    <a class="nav-link dropdown-toggle" href="#" id="logoutDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Log Out <i class="fas fa-sign-out-alt"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="logoutDropdown">
                        <li class="d-flex align-items-center">
                            <i class="bi bi-person-fill me-2"></i><a class="dropdown-item" href="profile.php">My Profile</a>
                        </li>
                        <li class="d-flex align-items-center">
                            <i class="fas fa-bookmark me-2"></i><a class="dropdown-item" href="reservations.php">Bookings Reservation</a>
                        </li>
                        <li class="d-flex align-items-center">
                            <i class="fas fa-box-open me-2"></i><a class="dropdown-item" href="myorders.php">My Orders</a>
                        </li>
                        <li class="d-flex align-items-center">
                            <i class="fas fa-sign-out-alt me-2"></i><a class="dropdown-item" href="logout.php">Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

    <section class="container contact-section">
    <h2 class="section-title">Contact Us</h2>
    <div class="row">
        <p>We’re here to help! Whether you have questions, feedback, or need assistance, our team is ready to support you. Reach out to us via phone, email, or the contact form below, and we’ll get back to you as soon as possible. We look forward to connecting with you!</p>
        <!-- Contact Form -->
        <div class="col-md-6 contact-form">
            <form id="contactForm" action="contactus.php" method="post">
                <div class="form-group">
                    <label for="name">Name*</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="email">Email Address*</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="message">Message*</label>
                    <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                </div>
                <button type="submit" class="btn btn-warning">Submit</button>
            </form>
            <div id="liveAlertPlaceholder"></div> <!-- Alert placeholder -->
        </div>
        <!-- Contact Information -->
        <div class="col-md-6 contact-info">
            <div class="d-flex align-items-center mb-3">
                <i class="fab fa-facebook"></i>
                <a href="https://web.facebook.com/casaestelahotelcafe">Casa Estela Boutique Hotel & Café</a>
            </div>
            <div class="d-flex align-items-center mb-3">
                <i class="fas fa-envelope"></i>
                <a href="mailto:casaestelahotelcafe@gmail.com">casaestelahotelcafe@gmail.com</a>
            </div>
            <div class="d-flex align-items-center mb-3">
                <i class="fas fa-phone"></i>
                <a href="tel:+09087474892">0908 747 4892</a>
            </div>
            <div class="d-flex align-items-center mb-3">
                <i class="fab fa-twitter"></i>
                <a href="">@casaestelahlcf</a>
            </div>
            <div class="d-flex align-items-center">
                <i class="fab fa-instagram"></i>
                <a href="https://www.instagram.com/casaestelahotelcafe/?fbclid=IwY2xjawGi8UFleHRuA2FlbQIxMAABHYc3XwOkKfq7GxCam4hYZ2z6t22JbwK87xhQtUeTbjd9aWtTsd_mcxFn9w_aem_pxRcb8rmqtB_xXBTbSdFbw#">@casaestelahotelcafe</a>
            </div>
        </div>
    </div>
</section>

    <!-- Footer -->
    <div class="footer"> @E-CasaLink All Rights Reserved 2024</div>
    <script>
 const alertPlaceholder = document.getElementById('liveAlertPlaceholder');

const appendAlert = (message, type) => {
    const wrapper = document.createElement('div');
    wrapper.innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>`;
    alertPlaceholder.append(wrapper);
};

document.getElementById('contactForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const formData = new FormData(this);

    fetch('contactus.php', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                appendAlert(data.message, 'success');
                this.reset();
            } else {
                appendAlert(data.message, 'danger');
            }
        })
        .catch(error => {
            appendAlert('Something went wrong. Please try again later.', 'danger');
            console.error('Error:', error);
        });
});

    </script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
