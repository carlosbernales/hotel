<?php
require_once "db.php";
session_start();
if (isset($_SESSION['user_id'])){
    $user_id = $_SESSION['user_id'];
    $userQuery = "SELECT * FROM user WHERE id = '$user_id'";
    $result = mysqli_query($con, $userQuery);
    $user = mysqli_fetch_assoc($result);
}else{
    header('Location:login.php');
}
include_once "header.php";
include_once "sidebar.php";

// Default page is dashboard
$page = 'dashboard.php';

if (isset($_GET['room_mang'])){
    $page = "room_mang.php";
}
elseif (isset($_GET['dashboard'])){
    $page = "dashboard.php";
}
elseif(isset($_GET['UserInfo'])){
    $page = "UserInfo.php";
}
elseif(isset($_GET['Order'])){
    $page = "Order.php";
}
elseif(isset($_GET['BookingList'])){
    $page = "BookingList.php";
}
elseif (isset($_GET['reservation'])){
    $page = "reservation.php";
}
elseif (isset($_GET['staff_mang'])){
    $page = "staff_mang.php";
}
elseif (isset($_GET['add_emp'])){
    $page = "add_emp.php";
}
elseif (isset($_GET['complain'])){
    $page = "Feedback.php";
}
elseif (isset($_GET['statistics'])){
    $page = "statistics.php";
}
elseif (isset($_GET['payment_settings'])){
    $page = "payment_settings.php";
}
elseif (isset($_GET['announcements'])){
    $page = "announcements.php";
}
elseif (isset($_GET['room_types'])){
    $page = "room_types.php";
}
elseif (isset($_GET['emp_history'])){
    $page = "emp_history.php";
}

// Include the selected page
include_once $page;
include_once "footer.php";