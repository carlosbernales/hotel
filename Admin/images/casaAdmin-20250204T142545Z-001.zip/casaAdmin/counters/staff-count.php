<?php 
    require_once dirname(__FILE__) . '/../db.php';
    $sql = "SELECT * FROM staff WHERE status = 'active'";
    $query = $con->query($sql);
    if ($query !== false) {
        echo $query->num_rows;
    } else {
        echo "0";
        // You might want to log the error here
        error_log("Database query failed in staff-count.php");
    }
?>