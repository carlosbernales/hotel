<?php
include_once "db.php";
include_once "header.php";
include_once "sidebar.php";

// Fetch room type statistics
$room_stats_query = "SELECT rt.room_type, COUNT(r.room_id) as count 
                    FROM room r 
                    JOIN room_type rt ON r.room_type_id = rt.room_type_id 
                    GROUP BY rt.room_type";
$room_stats_result = mysqli_query($con, $room_stats_query);
$room_stats_data = [];
while($row = mysqli_fetch_assoc($room_stats_result)) {
    $room_stats_data[] = [$row['room_type'], (int)$row['count']];
}

// Fetch monthly revenue data for the current year
$revenue_query = "SELECT MONTH(booking_date) as month, SUM(total_price) as revenue 
                 FROM booking 
                 WHERE YEAR(booking_date) = YEAR(CURRENT_DATE)
                 GROUP BY MONTH(booking_date)
                 ORDER BY month";
$revenue_result = mysqli_query($con, $revenue_query);
$revenue_data = [];
while($row = mysqli_fetch_assoc($revenue_result)) {
    $month_name = date('F', mktime(0, 0, 0, $row['month'], 10));
    $revenue_data[] = [$month_name, (float)$row['revenue'], "gold"];
}

// Fetch booking data for calendar
$booking_query = "SELECT DATE(booking_date) as date, COUNT(*) as count 
                 FROM booking 
                 WHERE booking_date >= DATE_SUB(CURRENT_DATE, INTERVAL 6 MONTH)
                 GROUP BY DATE(booking_date)";
$booking_result = mysqli_query($con, $booking_query);
$booking_data = [];
while($row = mysqli_fetch_assoc($booking_result)) {
    $date = new DateTime($row['date']);
    $booking_data[] = sprintf("[ new Date(%d, %d, %d), %d ]",
        (int)$date->format('Y'),
        (int)$date->format('m') - 1, // JavaScript months are 0-based
        (int)$date->format('d'),
        (int)$row['count']
    );
}

// Add error reporting for debugging
if (!$room_stats_result || !$revenue_result || !$booking_result) {
    echo "Database Error: " . mysqli_error($con);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sales & Statistics Report</title>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load("current", {packages:["corechart", "calendar"]});
        
        // Room Type Distribution Chart
        google.charts.setOnLoadCallback(drawRoomChart);
        function drawRoomChart() {
            var data = google.visualization.arrayToDataTable([
                ['Room Type', 'Count'],
                <?php
                foreach($room_stats_data as $row) {
                    echo sprintf("['%s', %d],", $row[0], $row[1]);
                }
                ?>
            ]);

            var options = {
                title: 'Room Type Distribution',
                is3D: true,
                backgroundColor: 'transparent'
            };

            var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
            chart.draw(data, options);
        }

        // Monthly Revenue Chart
        google.charts.setOnLoadCallback(drawRevenueChart);
        function drawRevenueChart() {
            var data = google.visualization.arrayToDataTable([
                ["Month", "Revenue", { role: "style" }],
                <?php
                foreach($revenue_data as $row) {
                    echo sprintf("['%s', %.2f, '%s'],", $row[0], $row[1], $row[2]);
                }
                ?>
            ]);

            var view = new google.visualization.DataView(data);
            view.setColumns([0, 1,
                           { calc: "stringify",
                             sourceColumn: 1,
                             type: "string",
                             role: "annotation" },
                           2]);

            var options = {
                title: "Monthly Revenue (Current Year)",
                backgroundColor: 'transparent',
                width: 410,
                height: 400,
                bar: {groupWidth: "95%"},
                legend: { position: "none" },
            };
            var chart = new google.visualization.BarChart(document.getElementById("barchart_values"));
            chart.draw(view, options);
        }

        // Booking Calendar Chart
        google.charts.setOnLoadCallback(drawCalendarChart);
        function drawCalendarChart() {
            var dataTable = new google.visualization.DataTable();
            dataTable.addColumn({ type: 'date', id: 'Date' });
            dataTable.addColumn({ type: 'number', id: 'Bookings' });
            dataTable.addRows([
                <?php echo implode(",\n                ", $booking_data); ?>
            ]);

            var options = {
                title: "Daily Bookings",
                height: 350,
                backgroundColor: 'transparent'
            };

            var chart = new google.visualization.Calendar(document.getElementById('calendar_basic'));
            chart.draw(dataTable, options);
        }
    </script>
    <style>
        .report-container {
            padding: 20px;
            margin: 20px;
            border-radius: 5px;
        }
        .chart-wrapper {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        #piechart_3d {
            width: 400px; 
            height: 400px;
            margin-left: 300px;
        }
        #barchart_values {
            width: 400px; 
            height: 400px;
            margin-left: 800px;
            margin-top: -400px;
        }
        #calendar_basic {
            width: 1000px; 
            height: 250px;
            margin-left: 300px;
        }
    </style>
</head>
<body>
    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Sales & Statistics Report</h1>
            </div>
        </div>
        <div class="report-container">
            <div class="chart-wrapper">
                <div id="piechart_3d"></div>
            </div>
            <div class="chart-wrapper">
                <div id="barchart_values"></div>
            </div>
            <div class="chart-wrapper">
                <div id="calendar_basic"></div>
            </div>
        </div>
    </div>
</body>
</html>
<?php include_once "footer.php"; ?>