<?php
include 'db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $id = $_POST['id'];
        
        $query = "DELETE FROM announcements WHERE id = ?";
        $stmt = $con->prepare($query);
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => $con->error]);
        }
    } else {
        $title = $_POST['title'];
        $message = $_POST['message'];
        $type = $_POST['type'];
        $valid_until = $_POST['valid_until'];
        
        $query = "INSERT INTO announcements (title, message, type, valid_until, created_at) VALUES (?, ?, ?, ?, NOW())";
        $stmt = $con->prepare($query);
        $stmt->bind_param("ssss", $title, $message, $type, $valid_until);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => $con->error]);
        }
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
?>
