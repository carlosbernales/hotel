<?php
include 'db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $booking_id = $_POST['booking_id'];
    
    // Update booking status
    $query = "UPDATE booking SET status = 'checked_out', actual_check_out = NOW() WHERE booking_id = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param("i", $booking_id);
    
    if ($stmt->execute()) {
        // Update room status to available
        $query = "UPDATE rooms r 
                 JOIN booking b ON r.room_id = b.room_id 
                 SET r.status = 'available' 
                 WHERE b.booking_id = ?";
        $stmt = $con->prepare($query);
        $stmt->bind_param("i", $booking_id);
        $stmt->execute();
        
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $con->error]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
?>
