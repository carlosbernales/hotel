<?php
include 'db.php';
include 'header.php';
include 'sidebar.php';
?>

<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
    <div class="row">
        <ol class="breadcrumb">
            <li><a href="#"><img src="img/house.png" alt="Home Icon" style="width: 20px; height: 20px;"></a></li>
            <li class="active">Announcements</li>
        </ol>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Payment System Announcements</h1>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">Create New Announcement</div>
                <div class="panel-body">
                    <form id="announcementForm">
                        <div class="form-group">
                            <label>Title</label>
                            <input type="text" class="form-control" name="title" required>
                        </div>
                        <div class="form-group">
                            <label>Message</label>
                            <textarea class="form-control" name="message" rows="3" required></textarea>
                        </div>
                        <div class="form-group">
                            <label>Type</label>
                            <select class="form-control" name="type" required>
                                <option value="gcash">GCash</option>
                                <option value="maya">Maya</option>
                                <option value="general">General</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Valid Until</label>
                            <input type="datetime-local" class="form-control" name="valid_until" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Post Announcement</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">Active Announcements</div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Message</th>
                                    <th>Type</th>
                                    <th>Posted On</th>
                                    <th>Valid Until</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="announcementsList">
                                <?php
                                $query = "SELECT * FROM announcements WHERE valid_until > NOW() ORDER BY created_at DESC";
                                $result = mysqli_query($con, $query);
                                while($row = mysqli_fetch_array($result)) {
                                    echo "<tr>";
                                    echo "<td>".$row['title']."</td>";
                                    echo "<td>".$row['message']."</td>";
                                    echo "<td><span class='badge badge-".($row['type'] == 'gcash' ? 'info' : ($row['type'] == 'maya' ? 'success' : 'warning'))."'>".$row['type']."</span></td>";
                                    echo "<td>".date('M d, Y H:i', strtotime($row['created_at']))."</td>";
                                    echo "<td>".date('M d, Y H:i', strtotime($row['valid_until']))."</td>";
                                    echo "<td><button class='btn btn-danger btn-sm' onclick='deleteAnnouncement(".$row['id'].")'>Delete</button></td>";
                                    echo "</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('announcementForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('process_announcement.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            alert('Announcement posted successfully');
            location.reload();
        } else {
            alert('Error posting announcement');
        }
    });
});

function deleteAnnouncement(id) {
    if(confirm('Are you sure you want to delete this announcement?')) {
        fetch('process_announcement.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=delete&id=' + id
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('Announcement deleted successfully');
                location.reload();
            } else {
                alert('Error deleting announcement');
            }
        });
    }
}
</script>

<style>
.badge {
    padding: 5px 10px;
    border-radius: 4px;
    font-size: 12px;
}
.badge-info {
    background-color: #17a2b8;
    color: white;
}
.badge-success {
    background-color: #28a745;
    color: white;
}
.badge-warning {
    background-color: #ffc107;
    color: black;
}
</style>
