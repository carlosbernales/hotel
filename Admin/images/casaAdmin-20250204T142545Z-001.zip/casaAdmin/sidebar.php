<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
    <div class="profile-sidebar">
        <div class="profile-userpic">
            <img src="img/Casa.jfif" class="img-responsive" alt="">
        </div>
        <div class="profile-usertitle">
            <div class="profile-usertitle-status"><span class=""></span>Admin</div>
        </div>
        <div class="clear"></div>
    </div>
    <div class="divider"></div>
    <ul class="nav menu">
        
        <li><a href="index.php?dashboard"><em class="fa fa-dashboard">&nbsp;</em>Dashboard</a></li>
        <li><a href="index.php?UserInfo"><em class="fa fa-user">&nbsp;</em>Customer Info</a></li>
        <li><a href="index.php?reservation"><em class="fa fa-calendar">&nbsp;</em>Reservations</a></li>
        <li><a href="index.php?booking_status"><em class="fa fa-info-circle">&nbsp;</em>Booking Status</a></li>
        <li><a href="index.php?room_mang"><em class="fa fa-bed">&nbsp;</em>Room Management</a></li>
        <li><a href="index.php?room_types"><em class="fa fa-th-large">&nbsp;</em>Room Types</a></li>
        <li><a href="index.php?staff_mang"><em class="fa fa-users">&nbsp;</em>Staff Section</a></li>
        <li><a href="index.php?complain"><em class="fa fa-comments">&nbsp;</em>Feedback</a></li>
        <li><a href="index.php?statistics"><em class="fa fa-line-chart">&nbsp;</em>Sales Report</a></li>
       
        <li><a href="index.php?announcements"><em class="fa fa-bullhorn">&nbsp;</em>Announcements</a></li>
       

        
        <li>
            <button id="theme-toggle" style="width: 100%; padding: 10px 20px; background-color: #DAA520; color: white; border: none; cursor: pointer;"> Dark Mode</button>
        </li>
    </ul>
</div>


<style>
    /* Dark Mode Styling for Sidebar */
    .sidebar {
        transition: background-color 3.5s ease, color 3.5s ease; /* Smooth transition for color change */
    }

    .sidebar.dark-mode {
        background-color: #333; /* Dark background */
        color: white; /* White text in dark mode */
    }
    
    /* Optional: Adjust the active link colors in dark mode */
    .sidebar.dark-mode .nav.menu li a {
        color: white;
    }

    /* Optional: Style for active links */
    .sidebar.dark-mode .nav.menu li.active {
        background-color: #444;
    }

    /* Add transition for links */
    .sidebar .nav.menu li a {
        transition: color 2.3s ease; /* Smooth color transition for links */
    }

    /* Style for the active menu item */
    .sidebar .nav.menu li.active a {
        background-color: #DAA520; /* Goldenrod background for active item */
        color: white; /* White text for active item */
    }

    /* Hover effect for all sidebar items */
    .sidebar .nav.menu li a:hover {
        background-color: #DAA520; /* Goldenrod background on hover for any item */
        color: white; /* Text color white on hover */
    }
</style>

<script>
    // Get all the sidebar links
    const links = document.querySelectorAll('.sidebar .nav.menu li');

    // Add event listener to all links to make the clicked item active
    links.forEach(link => {
        link.addEventListener('click', function () {
            // Remove 'active' class from all items
            links.forEach(item => item.classList.remove('active'));

            // Add the 'active' class to the clicked item
            this.classList.add('active');
        });
    });

    // Dark Mode Handling
    const sidebar = document.getElementById('sidebar-collapse');
    const themeToggleButton = document.getElementById('theme-toggle');

    // Check if dark mode is saved in localStorage and apply it
    if (localStorage.getItem('sidebar-theme') === 'dark') {
        sidebar.classList.add('dark-mode');
        themeToggleButton.textContent = "Turn Off Dark Mode"; // Change button text to "Turn Off Dark Mode"
    }

    // Toggle dark mode on button click
    themeToggleButton.addEventListener('click', () => {
        sidebar.classList.toggle('dark-mode');
        
        // Change the button text based on the current mode
        if (sidebar.classList.contains('dark-mode')) {
            themeToggleButton.textContent = "Turn Off Dark Mode";
            localStorage.setItem('sidebar-theme', 'dark');  // Save the dark mode in localStorage
        } else {
            themeToggleButton.textContent = "Turn On Dark Mode";
            localStorage.setItem('sidebar-theme', 'light');  // Save the light mode in localStorage
        }
    });
</script>
