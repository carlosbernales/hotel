<?php
include_once "db.php";
?>

<html>
<head>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
    /* Body styling to ensure the image covers the entire viewport */
    body {
        margin: 0;
        height: 100vh;
        background: url('img/ce.jpg') no-repeat center center fixed; /* Background image */
        background-size: cover;
        position: relative;
        transition: background-color 0.3s, color 5.3s;
    }

    /* Light white overlay for the background */
    body::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(255, 255, 255, 0.5); /* Semi-transparent white */
        z-index: 1;
    }

    /* Dark mode styles */
    body.dark-mode {
        background-color: #121212; /* Dark background */
    }

    body.dark-mode::before {
        background: rgba(0, 0, 0, 0.6); /* Dark overlay */
    }

    /* Center the card in the container */
    .container {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh; /* Ensures the container fills the viewport height */
        position: relative;
        z-index: 2;
    }

    /* Card container styling with golden border */
    .card-container {
        background-color: rgba(255, 255, 255, 0.9); /* Slightly transparent white */
        padding: 20px;
        border-radius: 10px;
        border: 2px solid #ffd700; /* Golden border */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3); /* Subtle shadow effect */
        text-align: center;
        width: 400px;
    }

    /* Dark mode card container */
    body.dark-mode .card-container {
        background-color: rgba(33, 33, 33, 0.9); /* Darker background for the card */
        border: 2px solid #b8860b; /* Golden border */
    }

    /* Profile image */
    #profile-img {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        margin-bottom: 10px;
    }

    /* Input fields */
    .form-control {
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        font-size: 14px;
        margin-bottom: 15px;
    }

    /* Dark mode form control */
    body.dark-mode .form-control {
        background-color: #333; /* Dark background for input */
        color: white; /* White text in input */
        border: 1px solid #444; /* Darker border */
    }

    /* Labels */
    label {
        font-weight: bold;
        font-size: 14px;
        color: #333;
        text-align: left;
        display: block;
        margin-bottom: 5px;
    }

    /* Dark mode labels */
    body.dark-mode label {
        color: #ccc; /* Lighter text color */
    }

    /* Buttons */
    .btn-primary {
        background-color: transparent; /* Transparent background */
        border: 2px solid #b8860b; /* Golden border */
        color: #b8860b; /* Golden text color */
        font-weight: bold;
        border-radius: 5px;
        width: 100%;
        padding: 10px;
        margin-top: 10px;
    }

    /* Hover effect for the Login button */
    .btn-primary:hover {
        background-color: #b8860b; /* Golden background on hover */
        color: #000; /* Change text color to black on hover */
    }

    /* Dark mode button */
    body.dark-mode .btn-primary {
        border: 2px solid #ffcc00; /* Lighter golden border in dark mode */
        color: #ffcc00; /* Lighter golden text */
    }

    /* Footer */
    footer {
        text-align: center;
        font-size: 12px;
        color: #333;
        margin-top: 15px;
    }

    footer a {
        text-decoration: none;
        color: #000;
        font-weight: bold;
    }

    /* Dark mode footer */
    body.dark-mode footer {
        color: #ccc; /* Lighter text in footer */
    }

    /* Dark mode toggle button */
    #dark-mode-toggle {
        background-color: #333;
        color: white;
        border: none;
        border-radius: 20px;
        padding: 8px 15px;
        cursor: pointer;
        font-size: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    #dark-mode-toggle:hover {
        background-color: #444;
    }

    #dark-mode-toggle i {
        margin-right: 5px;
    }
</style>
</head>
<body>

<div class="container">
    <div class="card card-container">
        <img id="profile-img" class="profile-img-card" src="img/download.jfif"/>
        
        <br>
        <div class="result">
            <?php
            if (isset($_GET['empty'])){
                echo '<div class="alert alert-danger">Enter Username or Password</div>';
            } elseif (isset($_GET['loginE'])){
                echo '<div class="alert alert-danger">Username or Password Don\'t Match</div>';
            } ?>
        </div>
        <form class="form-signin" data-toggle="validator" action="ajax.php" method="post">
            <div class="row">
                <div class="form-group col-lg-12">
                    <label>Username or Email</label>
                    <input type="text" name="email" class="form-control" placeholder="" required
                           data-error="Enter Username or Email">
                    <div class="help-block with-errors"></div>
                </div>
                <div class="form-group col-lg-12">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" placeholder="" required
                           data-error="Enter Password">
                    <div class="help-block with-errors"></div>
                </div>
            </div>

            <button class="btn btn-primary" type="submit" name="login">LOGIN</button>
       
        </form><!-- /form -->
        
        <!-- Dark mode toggle button -->
        <button class="btn" id="dark-mode-toggle">
            <i class="fas fa-moon"></i> Dark Mode
        </button>
    </div><!-- /card-container -->
</div><!-- /container -->

<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/validator.min.js"></script>

<script>
    // JavaScript function to toggle dark mode
    document.getElementById('dark-mode-toggle').addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
    });
</script>

<!-- Include Font Awesome for the moon icon -->
<script src="https://kit.fontawesome.com/a076d05399.js"></script>

</body>
</html>
