<?php
// Sample user details for insertion
$users = [
    ['email' => 'admin@example.com', 'password' => 'adminpassword', 'user_type' => 'admin'],
    ['email' => 'frontdesk@example.com', 'password' => 'frontdeskpassword', 'user_type' => 'frontdesk'],
    ['email' => 'cashier@example.com', 'password' => 'cashierpassword', 'user_type' => 'cashier']
];

// Insert users into the database
foreach ($users as $user) {
    $email = $user['email'];
    $password = password_hash($user['password'], PASSWORD_DEFAULT); // Hash the password
    $user_type = $user['user_type'];

    // Prepare the query
    $query = "INSERT INTO userss (email, password, user_type) VALUES (?, ?, ?)";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('sss', $email, $password, $user_type); // Bind parameters
    $stmt->execute();
}

echo "Users created successfully!";
?>
